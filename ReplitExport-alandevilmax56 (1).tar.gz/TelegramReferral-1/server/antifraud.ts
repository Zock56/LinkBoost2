import { 
  ClickLog, 
  InsertClickLog, 
  FraudRule, 
  IpRestriction 
} from "@shared/schema";

// Definición de tipos para las condiciones de reglas de fraude
interface BaseCondition {
  type: string;
}

interface MaxClicksPerIpCondition extends BaseCondition {
  type: "max_clicks_per_ip";
  timeWindowMinutes: number;
  threshold: number;
}

interface MaxClicksPerLinkPerIpCondition extends BaseCondition {
  type: "max_clicks_per_link_per_ip";
  timeWindowMinutes: number;
  threshold: number;
}

interface IpInRestrictionsCondition extends BaseCondition {
  type: "ip_in_restrictions";
}

type FraudRuleCondition = 
  | MaxClicksPerIpCondition 
  | MaxClicksPerLinkPerIpCondition 
  | IpInRestrictionsCondition;

// Interfaz para una solicitud de clic
export interface ClickRequest {
  linkId: number;
  userId?: number;
  ipAddress: string;
  userAgent?: string;
  metadata?: Record<string, any>;
}

// Interfaz para el resultado de la verificación de fraude
export interface FraudCheckResult {
  isValid: boolean;
  fraudScore: number;
  reason?: string;
  clickId?: number;
}

// Sistema Anti-Fraude
export class AntiFraudSystem {
  private clickLogs: Map<number, ClickLog>;
  private fraudRules: Map<number, FraudRule>;
  private ipRestrictions: Map<string, IpRestriction>;
  
  private currentClickId: number;
  private currentRuleId: number;
  private currentRestrictionId: number;
  
  // Límites y umbrales de configuración
  private MAX_CLICKS_PER_IP_PER_DAY = 10;
  private MAX_CLICKS_PER_LINK_PER_IP_PER_DAY = 3;
  private readonly FRAUD_SCORE_THRESHOLD = 50;
  
  constructor() {
    this.clickLogs = new Map();
    this.fraudRules = new Map();
    this.ipRestrictions = new Map();
    
    this.currentClickId = 1;
    this.currentRuleId = 1;
    this.currentRestrictionId = 1;
    
    // Inicializar las reglas de fraude por defecto
    this.initializeDefaultRules();
  }
  
  private initializeDefaultRules() {
    // Regla 1: Demasiados clics desde la misma IP en poco tiempo
    const tooManyClicksRule: FraudRule = {
      id: this.currentRuleId++,
      name: "Too Many Clicks From IP",
      description: "Detects when an IP address generates too many clicks within a short time period",
      condition: {
        type: "max_clicks_per_ip",
        timeWindowMinutes: 60,
        threshold: this.MAX_CLICKS_PER_IP_PER_DAY
      },
      scoreImpact: 30,
      isActive: true,
      createdAt: new Date()
    };
    this.fraudRules.set(tooManyClicksRule.id, tooManyClicksRule);
    
    // Regla 2: Demasiados clics al mismo enlace desde la misma IP
    const tooManyClicksOnLinkRule: FraudRule = {
      id: this.currentRuleId++,
      name: "Too Many Clicks On Same Link From IP",
      description: "Detects when an IP address clicks the same link too many times",
      condition: {
        type: "max_clicks_per_link_per_ip",
        timeWindowMinutes: 1440, // 24 horas
        threshold: this.MAX_CLICKS_PER_LINK_PER_IP_PER_DAY
      },
      scoreImpact: 40,
      isActive: true,
      createdAt: new Date()
    };
    this.fraudRules.set(tooManyClicksOnLinkRule.id, tooManyClicksOnLinkRule);
    
    // Regla 3: IP restringida
    const restrictedIpRule: FraudRule = {
      id: this.currentRuleId++,
      name: "Restricted IP",
      description: "Blocks clicks from IPs that have been explicitly restricted",
      condition: {
        type: "ip_in_restrictions"
      },
      scoreImpact: 100, // Automáticamente rechaza el clic
      isActive: true,
      createdAt: new Date()
    };
    this.fraudRules.set(restrictedIpRule.id, restrictedIpRule);
  }
  
  // Verificar si un clic es fraudulento
  async checkClick(clickRequest: ClickRequest): Promise<FraudCheckResult> {
    // Verificar si la IP está en la lista de restricciones
    const ipRestriction = this.getIpRestriction(clickRequest.ipAddress);
    if (ipRestriction) {
      // Si la restricción ha expirado, eliminarla y permitir rehabilitación
      if (ipRestriction.expiresAt && new Date() > ipRestriction.expiresAt) {
        console.log(`IP ${clickRequest.ipAddress} ha sido rehabilitada después de un período de restricción.`);
        this.ipRestrictions.delete(ipRestriction.ipAddress);
        
        // Limpiar los registros antiguos para esta IP para darle una "segunda oportunidad"
        const now = new Date();
        const clicksFromIp = Array.from(this.clickLogs.values())
            .filter(log => log.ipAddress === clickRequest.ipAddress);
            
        // Solo mantener registros de las últimas 2 horas
        const recentClicks = clicksFromIp.filter(log => 
            new Date(log.timestamp) > new Date(now.getTime() - 2 * 60 * 60 * 1000));
            
        // Si hay más de 5 clicks recientes, mantener solo los 5 más recientes
        if (recentClicks.length > 5) {
            recentClicks.sort((a, b) => 
                new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
            
            // Mantener solo los 5 más recientes
            const clicksToKeep = recentClicks.slice(0, 5);
            
            // Eliminar todos los registros antiguos para esta IP
            clicksFromIp.forEach(log => {
                if (!clicksToKeep.includes(log)) {
                    this.clickLogs.delete(log.id);
                }
            });
        }
      } else {
        // IP restringida, rechazar el clic
        return {
          isValid: false,
          fraudScore: 100,
          reason: `IP restricted: ${ipRestriction.reason || "Suspicious activity"}`
        };
      }
    }
    
    // Calcular puntuación de fraude
    let fraudScore = 0;
    let reason = "";
    
    // Aplicar cada regla activa
    for (const rule of Array.from(this.fraudRules.values())) {
      if (!rule.isActive) continue;
      
      const ruleScore = this.applyRule(rule, clickRequest);
      if (ruleScore > 0) {
        fraudScore += ruleScore;
        reason += `${rule.name} (+${ruleScore}), `;
      }
    }
    
    // Registrar el clic
    const isValid = fraudScore < this.FRAUD_SCORE_THRESHOLD;
    const clickLog = await this.logClick({
      linkId: clickRequest.linkId,
      userId: clickRequest.userId,
      ipAddress: clickRequest.ipAddress,
      userAgent: clickRequest.userAgent,
      fraudScore,
      isValid,
      metadata: clickRequest.metadata
    });
    
    // Si el puntaje está por encima del umbral, añadir restricción de IP temporal
    if (fraudScore >= this.FRAUD_SCORE_THRESHOLD) {
      this.addIpRestriction({
        ipAddress: clickRequest.ipAddress,
        restrictionType: "temporary",
        reason: reason.slice(0, -2), // Eliminar la última coma y espacio
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 horas
      });
    }
    
    return {
      isValid,
      fraudScore,
      reason: reason.length > 0 ? reason.slice(0, -2) : undefined,
      clickId: clickLog.id
    };
  }
  
  // Aplicar una regla de fraude a una solicitud de clic
  private applyRule(rule: FraudRule, clickRequest: ClickRequest): number {
    // Hacer un cast seguro de la condición al tipo FraudRuleCondition
    const condition = rule.condition as unknown as FraudRuleCondition;
    
    switch (condition.type) {
      case "max_clicks_per_ip": {
        const maxClicksCondition = condition as MaxClicksPerIpCondition;
        return this.checkMaxClicksPerIp(
          clickRequest.ipAddress,
          maxClicksCondition.timeWindowMinutes,
          maxClicksCondition.threshold,
          rule.scoreImpact
        );
      }
        
      case "max_clicks_per_link_per_ip": {
        const maxClicksLinkCondition = condition as MaxClicksPerLinkPerIpCondition;
        return this.checkMaxClicksPerLinkPerIp(
          clickRequest.linkId,
          clickRequest.ipAddress,
          maxClicksLinkCondition.timeWindowMinutes,
          maxClicksLinkCondition.threshold,
          rule.scoreImpact
        );
      }
        
      case "ip_in_restrictions":
        return this.ipRestrictions.has(clickRequest.ipAddress) ? rule.scoreImpact : 0;
        
      default:
        return 0;
    }
  }
  
  // Verificar si hay demasiados clics desde una IP en un período de tiempo
  private checkMaxClicksPerIp(
    ipAddress: string,
    timeWindowMinutes: number,
    threshold: number,
    scoreImpact: number
  ): number {
    const cutoffTime = new Date(Date.now() - timeWindowMinutes * 60 * 1000);
    
    const clicksFromIp = Array.from(this.clickLogs.values()).filter(log => 
      log.ipAddress === ipAddress && new Date(log.timestamp) > cutoffTime
    );
    
    return clicksFromIp.length >= threshold ? scoreImpact : 0;
  }
  
  // Verificar si hay demasiados clics en un enlace desde una IP en un período de tiempo
  private checkMaxClicksPerLinkPerIp(
    linkId: number,
    ipAddress: string,
    timeWindowMinutes: number,
    threshold: number,
    scoreImpact: number
  ): number {
    const cutoffTime = new Date(Date.now() - timeWindowMinutes * 60 * 1000);
    
    const clicksOnLinkFromIp = Array.from(this.clickLogs.values()).filter(log => 
      log.linkId === linkId && 
      log.ipAddress === ipAddress && 
      new Date(log.timestamp) > cutoffTime
    );
    
    return clicksOnLinkFromIp.length >= threshold ? scoreImpact : 0;
  }
  
  // Registrar un clic en el log
  async logClick(logData: InsertClickLog): Promise<ClickLog> {
    const id = this.currentClickId++;
    const timestamp = new Date();
    
    // Asegurarse de que userId es null si no está definido
    // y que todos los demás campos requeridos están presentes
    const clickLog: ClickLog = {
      id,
      linkId: logData.linkId,
      userId: logData.userId || null, // Convertir undefined a null
      ipAddress: logData.ipAddress,
      userAgent: logData.userAgent || null,
      timestamp,
      fraudScore: logData.fraudScore || 0,
      isValid: logData.isValid !== false,
      metadata: logData.metadata || null
    };
    
    this.clickLogs.set(id, clickLog);
    return clickLog;
  }
  
  // Añadir una restricción de IP
  async addIpRestriction(restriction: Omit<IpRestriction, "id" | "createdAt">): Promise<IpRestriction> {
    const id = this.currentRestrictionId++;
    const createdAt = new Date();
    
    const ipRestriction: IpRestriction = {
      ...restriction,
      id,
      createdAt
    };
    
    this.ipRestrictions.set(restriction.ipAddress, ipRestriction);
    return ipRestriction;
  }
  
  // Obtener una restricción de IP por dirección
  getIpRestriction(ipAddress: string): IpRestriction | undefined {
    return this.ipRestrictions.get(ipAddress);
  }
  
  // Obtener todos los clics registrados
  getClickLogs(): ClickLog[] {
    return Array.from(this.clickLogs.values());
  }
  
  // Obtener todas las reglas de fraude
  getFraudRules(): FraudRule[] {
    return Array.from(this.fraudRules.values());
  }
  
  // Obtener todas las restricciones de IP
  getIpRestrictions(): IpRestriction[] {
    return Array.from(this.ipRestrictions.values());
  }
  
  // Ajustar dinámicamente los umbrales basados en el tráfico
  async adjustThresholds(): Promise<void> {
    // Obtener todas las entradas de log de los últimos 7 días
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const recentLogs = Array.from(this.clickLogs.values())
      .filter(log => new Date(log.timestamp) > sevenDaysAgo);
      
    if (recentLogs.length < 100) {
      // No tenemos suficientes datos para ajustar los umbrales
      return;
    }
    
    // Calcular estadísticas básicas
    const clicksPerIP = new Map<string, number>();
    const clicksPerLinkPerIP = new Map<string, number>();
    
    recentLogs.forEach(log => {
      // Conteo de clics por IP
      const ipCount = clicksPerIP.get(log.ipAddress) || 0;
      clicksPerIP.set(log.ipAddress, ipCount + 1);
      
      // Conteo de clics por enlace por IP
      const linkIpKey = `${log.linkId}-${log.ipAddress}`;
      const linkIpCount = clicksPerLinkPerIP.get(linkIpKey) || 0;
      clicksPerLinkPerIP.set(linkIpKey, linkIpCount + 1);
    });
    
    // Calcular promedios
    const ipCounts = Array.from(clicksPerIP.values());
    const linkIpCounts = Array.from(clicksPerLinkPerIP.values());
    
    const avgClicksPerIP = ipCounts.reduce((sum, count) => sum + count, 0) / ipCounts.length;
    const avgClicksPerLinkPerIP = linkIpCounts.reduce((sum, count) => sum + count, 0) / linkIpCounts.length;
    
    // Calcular desviación estándar
    const stdDevIP = Math.sqrt(
      ipCounts.reduce((sum, count) => sum + Math.pow(count - avgClicksPerIP, 2), 0) / ipCounts.length
    );
    
    const stdDevLinkIP = Math.sqrt(
      linkIpCounts.reduce((sum, count) => sum + Math.pow(count - avgClicksPerLinkPerIP, 2), 0) / linkIpCounts.length
    );
    
    // Ajustar umbrales - utilizar promedio + 2 desviaciones estándar como nuevo umbral
    const newMaxClicksPerIP = Math.max(5, Math.round(avgClicksPerIP + 2 * stdDevIP));
    const newMaxClicksPerLinkPerIP = Math.max(3, Math.round(avgClicksPerLinkPerIP + 2 * stdDevLinkIP));
    
    // Actualizar umbrales solo si son significativamente diferentes
    if (Math.abs(this.MAX_CLICKS_PER_IP_PER_DAY - newMaxClicksPerIP) > 2) {
      console.log(`Ajustando umbral de clics por IP: ${this.MAX_CLICKS_PER_IP_PER_DAY} -> ${newMaxClicksPerIP}`);
      this.MAX_CLICKS_PER_IP_PER_DAY = newMaxClicksPerIP;
      
      // Actualizar la regla correspondiente
      const rule = Array.from(this.fraudRules.values())
        .find(r => (r.condition as any).type === "max_clicks_per_ip");
        
      if (rule) {
        const updatedRule: FraudRule = {
          ...rule,
          condition: {
            ...(rule.condition as any),
            threshold: newMaxClicksPerIP
          }
        };
        this.fraudRules.set(rule.id, updatedRule);
      }
    }
    
    if (Math.abs(this.MAX_CLICKS_PER_LINK_PER_IP_PER_DAY - newMaxClicksPerLinkPerIP) > 1) {
      console.log(`Ajustando umbral de clics por enlace por IP: ${this.MAX_CLICKS_PER_LINK_PER_IP_PER_DAY} -> ${newMaxClicksPerLinkPerIP}`);
      this.MAX_CLICKS_PER_LINK_PER_IP_PER_DAY = newMaxClicksPerLinkPerIP;
      
      // Actualizar la regla correspondiente
      const rule = Array.from(this.fraudRules.values())
        .find(r => (r.condition as any).type === "max_clicks_per_link_per_ip");
        
      if (rule) {
        const updatedRule: FraudRule = {
          ...rule,
          condition: {
            ...(rule.condition as any),
            threshold: newMaxClicksPerLinkPerIP
          }
        };
        this.fraudRules.set(rule.id, updatedRule);
      }
    }
  }
  
  // Generar un informe resumido sobre el tráfico y actividades de fraude
  generateFraudReport(days: number = 7): {
    totalClicks: number;
    validClicks: number;
    fraudulentClicks: number;
    fraudRate: number;
    topSuspiciousIPs: Array<{ip: string; fraudScore: number; clickCount: number}>;
    mostClickedLinks: Array<{linkId: number; clickCount: number}>;
    activeRestrictions: number;
  } {
    const now = new Date();
    const cutoffDate = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
    
    // Filtrar registros por fecha
    const recentLogs = Array.from(this.clickLogs.values())
      .filter(log => new Date(log.timestamp) > cutoffDate);
      
    // Contar clics válidos y fraudulentos
    const validClicks = recentLogs.filter(log => log.isValid).length;
    const fraudulentClicks = recentLogs.length - validClicks;
    const fraudRate = recentLogs.length > 0 ? (fraudulentClicks / recentLogs.length) * 100 : 0;
    
    // Análisis por IP
    const ipScores = new Map<string, {fraudScore: number; clickCount: number}>();
    recentLogs.forEach(log => {
      const current = ipScores.get(log.ipAddress) || {fraudScore: 0, clickCount: 0};
      ipScores.set(log.ipAddress, {
        fraudScore: current.fraudScore + log.fraudScore,
        clickCount: current.clickCount + 1
      });
    });
    
    // Top IPs sospechosas (ordenadas por puntuación de fraude)
    const topSuspiciousIPs = Array.from(ipScores.entries())
      .map(([ip, stats]) => ({
        ip,
        fraudScore: stats.fraudScore,
        clickCount: stats.clickCount
      }))
      .sort((a, b) => b.fraudScore - a.fraudScore)
      .slice(0, 5);
      
    // Enlaces más clicados
    const linkClicks = new Map<number, number>();
    recentLogs.forEach(log => {
      const count = linkClicks.get(log.linkId) || 0;
      linkClicks.set(log.linkId, count + 1);
    });
    
    const mostClickedLinks = Array.from(linkClicks.entries())
      .map(([linkId, clickCount]) => ({linkId, clickCount}))
      .sort((a, b) => b.clickCount - a.clickCount)
      .slice(0, 5);
      
    // Número de restricciones activas
    const activeRestrictions = this.ipRestrictions.size;
    
    return {
      totalClicks: recentLogs.length,
      validClicks,
      fraudulentClicks,
      fraudRate,
      topSuspiciousIPs,
      mostClickedLinks,
      activeRestrictions
    };
  }
}

// Exportar una instancia del sistema anti-fraude
export const antiFraudSystem = new AntiFraudSystem();