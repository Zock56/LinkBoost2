import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Ruta para servir la página de panel de rendimiento
  app.get("/performance", (req, res) => {
    res.sendFile(path.resolve(process.cwd(), "public", "performance.html"));
  });
  // Set up API routes (prefix with /api)
  
  // Users
  app.get("/api/users/me", async (req, res) => {
    try {
      // In a real app, this would use authenticated user ID from session
      const userId = 1; // Mock user ID for demo
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Referral Links
  app.get("/api/referral-links", async (req, res) => {
    try {
      // In a real app, this would use authenticated user ID from session
      const userId = 1; // Mock user ID for demo
      
      const links = await storage.getUserReferralLinks(userId);
      res.json(links);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/referral-links", async (req, res) => {
    try {
      // In a real app, this would use authenticated user ID from session
      const userId = 1; // Mock user ID for demo
      
      const newLink = await storage.createReferralLink({
        ...req.body,
        userId
      });
      
      res.status(201).json(newLink);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  app.delete("/api/referral-links/:id", async (req, res) => {
    try {
      const linkId = parseInt(req.params.id);
      
      if (isNaN(linkId)) {
        return res.status(400).json({ message: "Invalid link ID" });
      }
      
      const deleted = await storage.deleteReferralLink(linkId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Link not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Available Links
  app.get("/api/available-links", async (req, res) => {
    try {
      const links = await storage.getAvailableLinks();
      res.json(links);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Quests
  app.get("/api/quests", async (req, res) => {
    try {
      const quests = await storage.getQuests();
      res.json(quests);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/quests/:id/claim", async (req, res) => {
    try {
      // In a real app, this would use authenticated user ID from session
      const userId = 1; // Mock user ID for demo
      const questId = parseInt(req.params.id);
      
      const result = await storage.claimQuest(userId, questId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Share and boost links
  app.post("/api/share-link", async (req, res) => {
    try {
      // In a real app, this would use authenticated user ID from session
      const userId = 1; // Mock user ID for demo
      
      const result = await storage.shareLink(userId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/boost-links", async (req, res) => {
    try {
      // In a real app, this would use authenticated user ID from session
      const userId = 1; // Mock user ID for demo
      
      const result = await storage.boostLinks(userId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Sistema Anti-Fraude
  app.post("/api/record-click", async (req, res) => {
    try {
      const { linkId, userId, metadata } = req.body;
      
      // Obtener información de la solicitud
      const ipAddress = req.ip || req.socket.remoteAddress || "127.0.0.1";
      const userAgent = req.headers["user-agent"] || "";
      
      // Validar linkId
      if (!linkId || isNaN(parseInt(linkId))) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid link ID"
        });
      }
      
      // Registrar el clic a través del sistema anti-fraude
      const result = await storage.recordClick(
        parseInt(linkId),
        ipAddress,
        userId ? parseInt(userId) : undefined,
        userAgent,
        metadata
      );
      
      res.json(result);
    } catch (error) {
      console.error("Error recording click:", error);
      res.status(500).json({ 
        success: false, 
        isValid: false,
        message: "Server error"
      });
    }
  });
  
  // Para propósitos de administración y depuración, agregamos rutas para verificar
  // los registros de clics, reglas de fraude y restricciones de IP
  app.get("/api/fraud-checks/logs", async (req, res) => {
    try {
      // En una aplicación real, esto requeriría autenticación de administrador
      const antiFraudSystem = (storage as any).antiFraudSystem;
      
      if (!antiFraudSystem) {
        return res.status(500).json({ message: "Anti-fraud system not initialized" });
      }
      
      const logs = antiFraudSystem.getClickLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  app.get("/api/fraud-checks/rules", async (req, res) => {
    try {
      // En una aplicación real, esto requeriría autenticación de administrador
      const antiFraudSystem = (storage as any).antiFraudSystem;
      
      if (!antiFraudSystem) {
        return res.status(500).json({ message: "Anti-fraud system not initialized" });
      }
      
      const rules = antiFraudSystem.getFraudRules();
      res.json(rules);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  app.get("/api/fraud-checks/ip-restrictions", async (req, res) => {
    try {
      // En una aplicación real, esto requeriría autenticación de administrador
      const antiFraudSystem = (storage as any).antiFraudSystem;
      
      if (!antiFraudSystem) {
        return res.status(500).json({ message: "Anti-fraud system not initialized" });
      }
      
      const ipRestrictions = antiFraudSystem.getIpRestrictions();
      res.json(ipRestrictions);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Informe de fraude
  app.get("/api/fraud-checks/report", async (req, res) => {
    try {
      const days = req.query.days ? parseInt(req.query.days as string) : 7;
      
      // En una aplicación real, esto requeriría autenticación de administrador
      const antiFraudSystem = (storage as any).antiFraudSystem;
      
      if (!antiFraudSystem) {
        return res.status(500).json({ message: "Anti-fraud system not initialized" });
      }
      
      const report = antiFraudSystem.generateFraudReport(days);
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Ajustar umbrales de fraude
  app.post("/api/fraud-checks/adjust-thresholds", async (req, res) => {
    try {
      // En una aplicación real, esto requeriría autenticación de administrador
      const antiFraudSystem = (storage as any).antiFraudSystem;
      
      if (!antiFraudSystem) {
        return res.status(500).json({ message: "Anti-fraud system not initialized" });
      }
      
      await antiFraudSystem.adjustThresholds();
      
      // Devolver las reglas actualizadas
      const rules = antiFraudSystem.getFraudRules();
      res.json({
        success: true,
        message: "Thresholds adjusted based on traffic patterns",
        rules
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Performance Dashboard
  app.get("/api/performance/summary", async (req, res) => {
    try {
      // En una aplicación real, esto usaría el ID de usuario autenticado de la sesión
      const userId = 1; // ID de usuario simulado para esta demo
      const period = (req.query.period as 'day' | 'week' | 'month' | 'year') || 'week';
      
      const summary = await storage.getLinkPerformanceSummary(userId, period);
      res.json(summary);
    } catch (error) {
      console.error("Error getting performance summary:", error);
      // Enviar un objeto de respuesta válido incluso en caso de error
      res.status(500).json({ 
        message: "Server error", 
        totalClicks: 0,
        totalUniqueVisitors: 0,
        totalCompletedVisits: 0,
        totalRewardsEarned: 0,
        averageConversionRate: 0,
        topPerformingLinks: [],
        performanceByDate: []
      });
    }
  });
  
  app.get("/api/performance/link/:linkId", async (req, res) => {
    try {
      const linkId = parseInt(req.params.linkId);
      
      if (isNaN(linkId)) {
        return res.status(400).json({ message: "Invalid link ID" });
      }
      
      const performance = await storage.getLinkPerformance(linkId);
      res.json(performance);
    } catch (error) {
      console.error("Error getting link performance:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Sistema de reclamación de recompensas
  
  // Marcar un enlace como visitado (la app fue abierta)
  app.post("/api/mark-visited/:visitId", async (req, res) => {
    try {
      const visitId = parseInt(req.params.visitId);
      
      if (isNaN(visitId)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid visit ID" 
        });
      }
      
      const result = await storage.markLinkAsVisited(visitId);
      res.json(result);
    } catch (error) {
      console.error("Error marking link as visited:", error);
      res.status(500).json({ 
        success: false, 
        message: "Server error" 
      });
    }
  });
  
  // Reclamar la recompensa por haber visitado una aplicación
  app.post("/api/claim-reward/:visitId", async (req, res) => {
    try {
      // En una aplicación real, esto usaría el ID de usuario autenticado de la sesión
      const userId = 1; // ID de usuario simulado para esta demo
      const visitId = parseInt(req.params.visitId);
      
      if (isNaN(visitId)) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid visit ID",
          rewardAmount: 0
        });
      }
      
      const result = await storage.claimReward(visitId, userId);
      res.json(result);
    } catch (error) {
      console.error("Error claiming reward:", error);
      res.status(500).json({ 
        success: false, 
        message: "Server error",
        rewardAmount: 0
      });
    }
  });
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Configurar WebSocket server en la misma instancia del servidor HTTP
  // pero en una ruta diferente para no interferir con WebSockets de Vite
  // Configuración básica de WebSocket para iniciar sin problemas
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    // Enviar un mensaje simple para confirmar la conexión
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'connected', message: 'WebSocket connection established' }));
    }
    
    ws.on('message', (message) => {
      console.log('Received message on WebSocket');
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  return httpServer;
}
