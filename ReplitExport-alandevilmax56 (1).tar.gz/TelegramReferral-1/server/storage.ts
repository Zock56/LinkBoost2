import { 
  users, type User, type InsertUser,
  referralLinks, type ReferralLink, type InsertReferralLink,
  quests, type Quest, type InsertQuest,
  userQuestProgress, type UserQuestProgress, type InsertUserQuestProgress,
  availableLinks, type AvailableLink, type InsertAvailableLink,
  linkVisits, type LinkVisit, type InsertLinkVisit,
  linkPerformance, type LinkPerformance, type InsertLinkPerformance
} from "@shared/schema";

// Define the storage interface
export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserReputation(userId: number, amount: number): Promise<User>;
  
  // Referral Links
  getUserReferralLinks(userId: number): Promise<ReferralLink[]>;
  createReferralLink(link: InsertReferralLink): Promise<ReferralLink>;
  updateReferralLinkClicks(linkId: number, clicks: number): Promise<ReferralLink>;
  deleteReferralLink(linkId: number): Promise<boolean>;
  
  // Quests
  getQuests(): Promise<Quest[]>;
  getQuestProgress(userId: number, questId: number): Promise<UserQuestProgress | undefined>;
  claimQuest(userId: number, questId: number): Promise<{ success: boolean; reward: number; zcoinReward?: number }>;
  
  // Available Links
  getAvailableLinks(): Promise<AvailableLink[]>;
  
  // Actions
  shareLink(userId: number): Promise<{ success: boolean; zcoinGained: number }>;
  boostLinks(userId: number): Promise<{ success: boolean; message: string }>;
  
  // Anti-Fraude
  recordClick(
    linkId: number, 
    ipAddress: string, 
    userId?: number, 
    userAgent?: string, 
    metadata?: Record<string, any>
  ): Promise<{ 
    success: boolean; 
    isValid: boolean; 
    message?: string;
    fraudScore?: number;
    visitId?: number;
  }>;
  
  // Sistema de reclamación de recompensas
  registerVisit(
    linkId: number,
    ipAddress: string,
    userId?: number
  ): Promise<{
    success: boolean;
    message: string;
    visitId: number;
  }>;
  
  markLinkAsVisited(
    visitId: number
  ): Promise<{
    success: boolean;
    message: string;
  }>;
  
  claimReward(
    visitId: number,
    userId: number
  ): Promise<{
    success: boolean;
    message: string;
    rewardAmount: number;
  }>;
  
  // Dashboard de rendimiento
  getLinkPerformance(
    linkId: number,
    startDate?: Date,
    endDate?: Date
  ): Promise<LinkPerformance[]>;
  
  getLinkPerformanceSummary(
    userId: number,
    period?: 'day' | 'week' | 'month' | 'year'
  ): Promise<{
    totalClicks: number;
    totalUniqueVisitors: number;
    totalCompletedVisits: number;
    totalRewardsEarned: number;
    averageConversionRate: number;
    topPerformingLinks: Array<{
      linkId: number;
      name: string;
      clicks: number;
      conversionRate: number;
    }>;
    performanceByDate: Array<{
      date: Date;
      clicks: number;
      uniqueVisitors: number;
      completedVisits: number;
    }>;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private referralLinks: Map<number, ReferralLink>;
  private quests: Map<number, Quest>;
  private userQuestProgress: Map<string, UserQuestProgress>;
  private availableLinks: Map<number, AvailableLink>;
  private linkVisits: Map<number, LinkVisit>;
  private linkPerformances: Map<number, LinkPerformance[]>;
  
  // Importamos aquí para evitar dependencias circulares
  private antiFraudSystem: any; // Se inicializará después de la exportación de esta clase
  
  private currentUserId: number;
  private currentLinkId: number;
  private currentQuestId: number;
  private currentProgressId: number;
  private currentAvailableLinkId: number;

  private currentVisitId: number;

  constructor() {
    this.users = new Map();
    this.referralLinks = new Map();
    this.quests = new Map();
    this.userQuestProgress = new Map();
    this.availableLinks = new Map();
    this.linkVisits = new Map();
    this.linkPerformances = new Map();
    
    this.currentUserId = 1;
    this.currentLinkId = 1;
    this.currentQuestId = 1;
    this.currentProgressId = 1;
    this.currentAvailableLinkId = 1;
    this.currentVisitId = 1;
    
    // Initialize with demo data
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Inicializar datos de rendimiento de enlace para demo
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Crear algunos datos de rendimiento de ejemplo para los enlaces
    const demoPerformances: Record<number, LinkPerformance[]> = {
      1: [
        {
          id: 1,
          linkId: 1,
          date: yesterday,
          clicks: 12,
          uniqueVisitors: 8,
          completedVisits: 3,
          rewardsEarned: 30,
          conversionRate: "25.00",
          createdAt: yesterday
        },
        {
          id: 2,
          linkId: 1,
          date: now,
          clicks: 5,
          uniqueVisitors: 4,
          completedVisits: 2,
          rewardsEarned: 20,
          conversionRate: "40.00",
          createdAt: now
        }
      ],
      2: [
        {
          id: 3,
          linkId: 2,
          date: yesterday,
          clicks: 20,
          uniqueVisitors: 15,
          completedVisits: 10,
          rewardsEarned: 100,
          conversionRate: "50.00",
          createdAt: yesterday
        },
        {
          id: 4,
          linkId: 2,
          date: now,
          clicks: 8,
          uniqueVisitors: 6,
          completedVisits: 4,
          rewardsEarned: 40,
          conversionRate: "50.00",
          createdAt: now
        }
      ]
    };
    
    // Agregar datos de demo al mapa de rendimiento
    for (const [linkId, performances] of Object.entries(demoPerformances)) {
      this.linkPerformances.set(Number(linkId), performances);
    }
    // Create a demo user
    const demoUser: User = {
      id: this.currentUserId++,
      username: "demouser",
      password: "password123",
      telegramId: "123456789",
      reputation: 1250,
      rank: 305,
      todayRep: 70,
      friendsInvited: 13,
      totalRepFromFriends: 650,
      zcoinBalance: 100,
      createdAt: new Date()
    };
    this.users.set(demoUser.id, demoUser);

    // Create demo referral links
    const demoLinks: ReferralLink[] = [
      {
        id: this.currentLinkId++,
        userId: demoUser.id,
        name: "DreamStation A",
        clicks: 0,
        recentClicks: 0,
        rank: 794,
        totalLinks: 7221,
        isOverlinked: true,
        hasCoin: false,
        iconType: "blue",
        createdAt: new Date()
      },
      {
        id: this.currentLinkId++,
        userId: demoUser.id,
        name: "Virtual Tether",
        clicks: 3,
        recentClicks: 1,
        rank: 795,
        totalLinks: 7221,
        isOverlinked: false,
        hasCoin: true,
        iconType: "purple",
        createdAt: new Date()
      },
      {
        id: this.currentLinkId++,
        userId: demoUser.id,
        name: "tBTC Hash",
        clicks: 0,
        recentClicks: 0,
        rank: 796,
        totalLinks: 7221,
        isOverlinked: false,
        hasCoin: false,
        iconType: "gold",
        createdAt: new Date()
      }
    ];
    
    demoLinks.forEach(link => {
      this.referralLinks.set(link.id, link);
    });

    // Create demo quests
    const dailyQuest: Quest = {
      id: this.currentQuestId++,
      name: "Daily REP Bonus",
      description: "Claim your daily REP bonus",
      repReward: 10,
      zcoinReward: null,
      isDaily: true,
      createdAt: new Date()
    };
    this.quests.set(dailyQuest.id, dailyQuest);
    
    const watchAdQuest: Quest = {
      id: this.currentQuestId++,
      name: "Watch Video Ad",
      description: "Watch a video advertisement to earn 1 Zcoin",
      repReward: 5,
      zcoinReward: 1,
      isDaily: true,
      createdAt: new Date()
    };
    this.quests.set(watchAdQuest.id, watchAdQuest);

    // Create demo quest progress
    const questProgress: UserQuestProgress = {
      id: this.currentProgressId++,
      userId: demoUser.id,
      questId: dailyQuest.id,
      currentLevel: 0,
      completedAt: null,
      createdAt: new Date()
    };
    this.userQuestProgress.set(`${demoUser.id}-${dailyQuest.id}`, questProgress);
    
    const adQuestProgress: UserQuestProgress = {
      id: this.currentProgressId++,
      userId: demoUser.id,
      questId: watchAdQuest.id,
      currentLevel: 0,
      completedAt: null,
      createdAt: new Date()
    };
    this.userQuestProgress.set(`${demoUser.id}-${watchAdQuest.id}`, adQuestProgress);

    // Create demo available links
    const availableDemoLinks: AvailableLink[] = [
      {
        id: this.currentAvailableLinkId++,
        name: "DreamStation App",
        iconType: "blue",
        rank: 794,
        totalLinks: 7221,
        forUser: "Zock",
        repAmount: null,
        fromUser: null,
        createdAt: new Date()
      },
      {
        id: this.currentAvailableLinkId++,
        name: "TON YouTube",
        iconType: "red",
        rank: null,
        totalLinks: null,
        forUser: null,
        repAmount: 5,
        fromUser: "Rida02",
        createdAt: new Date()
      },
      {
        id: this.currentAvailableLinkId++,
        name: "LlamaPayday",
        iconType: "blue",
        rank: null,
        totalLinks: null,
        forUser: null,
        repAmount: 5,
        fromUser: "Antonio",
        createdAt: new Date()
      },
      {
        id: this.currentAvailableLinkId++,
        name: "planes",
        iconType: "blue",
        rank: null,
        totalLinks: null,
        forUser: null,
        repAmount: 5,
        fromUser: "Anastasia",
        createdAt: new Date()
      }
    ];
    
    availableDemoLinks.forEach(link => {
      this.availableLinks.set(link.id, link);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    
    const user: User = { 
      ...insertUser, 
      id,
      reputation: 100, // Los usuarios comienzan con 100 de reputación
      rank: 9999,
      todayRep: 0,
      friendsInvited: 0,
      totalRepFromFriends: 0,
      zcoinBalance: 25, // Los usuarios comienzan con 25 Zcoins
      createdAt: now
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUserReputation(userId: number, amount: number): Promise<User> {
    const user = await this.getUser(userId);
    
    if (!user) {
      throw new Error("User not found");
    }
    
    user.reputation += amount;
    user.todayRep += amount;
    
    // Update rank (simplified)
    user.rank = Math.max(1, 1000 - Math.floor(user.reputation / 10));
    
    this.users.set(userId, user);
    return user;
  }

  // Referral Link methods
  async getUserReferralLinks(userId: number): Promise<ReferralLink[]> {
    return Array.from(this.referralLinks.values()).filter(
      (link) => link.userId === userId
    );
  }

  async createReferralLink(insertLink: InsertReferralLink): Promise<ReferralLink> {
    const id = this.currentLinkId++;
    const now = new Date();
    
    const link: ReferralLink = {
      ...insertLink,
      id,
      clicks: 0,
      recentClicks: 0,
      rank: 1000, // Default rank
      totalLinks: 7221, // Mock total links
      isOverlinked: false,
      hasCoin: false,
      iconType: insertLink.iconType || "blue", // Ensure iconType is never undefined
      createdAt: now
    };
    
    this.referralLinks.set(id, link);
    return link;
  }

  async updateReferralLinkClicks(linkId: number, clicks: number): Promise<ReferralLink> {
    const link = Array.from(this.referralLinks.values()).find(
      (l) => l.id === linkId
    );
    
    if (!link) {
      throw new Error("Referral link not found");
    }
    
    link.clicks += clicks;
    link.recentClicks = clicks;
    
    // Update rank (simplified)
    if (link.clicks > 50) {
      link.rank = Math.max(1, link.rank - 10);
    }
    
    this.referralLinks.set(linkId, link);
    return link;
  }
  
  async deleteReferralLink(linkId: number): Promise<boolean> {
    const exists = this.referralLinks.has(linkId);
    
    if (!exists) {
      return false;
    }
    
    this.referralLinks.delete(linkId);
    return true;
  }

  // Quest methods
  async getQuests(): Promise<Quest[]> {
    return Array.from(this.quests.values());
  }

  async getQuestProgress(userId: number, questId: number): Promise<UserQuestProgress | undefined> {
    return this.userQuestProgress.get(`${userId}-${questId}`);
  }

  async claimQuest(userId: number, questId: number): Promise<{ success: boolean; reward: number; zcoinReward?: number }> {
    const quest = this.quests.get(questId);
    
    if (!quest) {
      throw new Error("Quest not found");
    }
    
    const progressKey = `${userId}-${questId}`;
    let progress = this.userQuestProgress.get(progressKey);
    
    if (!progress) {
      progress = {
        id: this.currentProgressId++,
        userId,
        questId,
        currentLevel: 0,
        completedAt: null,
        createdAt: new Date()
      };
    }
    
    // Check if already completed today
    const today = new Date();
    const completedDate = progress.completedAt;
    
    if (completedDate && 
        completedDate.getDate() === today.getDate() &&
        completedDate.getMonth() === today.getMonth() &&
        completedDate.getFullYear() === today.getFullYear() &&
        quest.isDaily) {
      return { success: false, reward: 0 };
    }
    
    // Claim the quest reward
    progress.currentLevel += 1;
    progress.completedAt = today;
    
    // Update the progress
    this.userQuestProgress.set(progressKey, progress);
    
    // Update user reputation
    await this.updateUserReputation(userId, quest.repReward);
    
    // Update Zcoin balance if there's a Zcoin reward
    if (quest.zcoinReward) {
      const user = await this.getUser(userId);
      if (user) {
        user.zcoinBalance += quest.zcoinReward;
        this.users.set(userId, user);
        return { success: true, reward: quest.repReward, zcoinReward: quest.zcoinReward };
      }
    }
    
    return { success: true, reward: quest.repReward };
  }

  // Available Links methods
  async getAvailableLinks(): Promise<AvailableLink[]> {
    return Array.from(this.availableLinks.values());
  }

  // Actions
  async shareLink(userId: number): Promise<{ success: boolean; zcoinGained: number }> {
    const zcoinAmount = 3;
    
    // Actualizar el saldo de Zcoin del usuario
    const user = await this.getUser(userId);
    if (user) {
      user.zcoinBalance += zcoinAmount;
      this.users.set(userId, user);
    }
    
    return { success: true, zcoinGained: zcoinAmount };
  }

  async boostLinks(userId: number): Promise<{ success: boolean; message: string }> {
    const user = await this.getUser(userId);
    
    if (!user) {
      throw new Error("User not found");
    }
    
    const links = await this.getUserReferralLinks(userId);
    
    if (links.length === 0) {
      return { success: false, message: "No links to boost" };
    }
    
    // Boost all links (simplified, just lower their rank)
    for (const link of links) {
      link.rank = Math.max(1, link.rank - 5);
      this.referralLinks.set(link.id, link);
    }
    
    return { success: true, message: "Links boosted successfully" };
  }
  
  // Sistema de reclamación de recompensas
  async registerVisit(
    linkId: number,
    ipAddress: string,
    userId?: number
  ): Promise<{
    success: boolean;
    message: string;
    visitId: number;
  }> {
    // Verificar que el enlace existe
    const link = this.referralLinks.get(linkId);
    if (!link) {
      throw new Error("Link not found");
    }
    
    // Crear una nueva visita
    const id = this.currentVisitId++;
    const now = new Date();
    
    const visit: LinkVisit = {
      id,
      linkId,
      userId: userId || null, // Convertir undefined a null
      ipAddress,
      visited: false,
      claimed: false,
      visitedAt: null,
      claimedAt: null,
      createdAt: now
    };
    
    this.linkVisits.set(id, visit);
    
    return {
      success: true,
      message: "Visit registered successfully",
      visitId: id
    };
  }
  
  async markLinkAsVisited(
    visitId: number
  ): Promise<{
    success: boolean;
    message: string;
  }> {
    const visit = this.linkVisits.get(visitId);
    
    if (!visit) {
      return {
        success: false,
        message: "Visit not found"
      };
    }
    
    if (visit.visited) {
      return {
        success: false,
        message: "Visit already marked as visited"
      };
    }
    
    // Marcar la visita como realizada
    visit.visited = true;
    visit.visitedAt = new Date();
    this.linkVisits.set(visitId, visit);
    
    return {
      success: true,
      message: "Link marked as visited"
    };
  }
  
  async claimReward(
    visitId: number,
    userId: number
  ): Promise<{
    success: boolean;
    message: string;
    rewardAmount: number;
  }> {
    const visit = this.linkVisits.get(visitId);
    
    if (!visit) {
      return {
        success: false,
        message: "Visit not found",
        rewardAmount: 0
      };
    }
    
    if (!visit.visited) {
      return {
        success: false,
        message: "You need to visit the app before claiming the reward",
        rewardAmount: 0
      };
    }
    
    if (visit.claimed) {
      return {
        success: false,
        message: "Reward already claimed",
        rewardAmount: 0
      };
    }
    
    // Verificar que el usuario que reclama es el mismo que generó la visita
    if (visit.userId && visit.userId !== userId) {
      return {
        success: false,
        message: "You can only claim rewards for your own visits",
        rewardAmount: 0
      };
    }
    
    // Dar la recompensa al usuario (10 Zcoins)
    const rewardAmount = 10;
    const user = await this.getUser(userId);
    
    if (!user) {
      return {
        success: false,
        message: "User not found",
        rewardAmount: 0
      };
    }
    
    // Actualizar el saldo de Zcoin del usuario
    user.zcoinBalance += rewardAmount;
    this.users.set(userId, user);
    
    // Marcar la visita como reclamada
    visit.claimed = true;
    visit.claimedAt = new Date();
    visit.userId = userId; // Aseguramos que el usuario quede registrado
    this.linkVisits.set(visitId, visit);
    
    // Actualizar estadísticas de rendimiento
    await this.updateLinkPerformance(visit.linkId, {
      clicks: 0,                // No incrementar clics
      uniqueVisitors: 0,        // No incrementar visitantes únicos
      completedVisits: 1,       // Incrementar visitas completadas
      rewardsEarned: rewardAmount // Registrar la recompensa ganada
    });
    
    return {
      success: true,
      message: `Congratulations! You've earned ${rewardAmount} Zcoins!`,
      rewardAmount
    };
  }
  
  // Anti-Fraud methods
  async recordClick(
    linkId: number, 
    ipAddress: string, 
    userId?: number, 
    userAgent?: string, 
    metadata?: Record<string, any>
  ): Promise<{ 
    success: boolean; 
    isValid: boolean; 
    message?: string;
    fraudScore?: number;
    visitId?: number;
  }> {
    // Verificar que el enlace existe
    const link = this.referralLinks.get(linkId);
    if (!link) {
      return { 
        success: false, 
        isValid: false, 
        message: "Link not found"
      };
    }
    
    // Verificar si el clic es válido mediante el sistema anti-fraude
    const clickRequest = {
      linkId,
      userId,
      ipAddress,
      userAgent,
      metadata
    };
    
    const fraudCheckResult = await this.antiFraudSystem.checkClick(clickRequest);
    
    // Si el clic es válido, actualizar el contador de clics del enlace
    if (fraudCheckResult.isValid) {
      await this.updateReferralLinkClicks(linkId, 1);
      
      // Si el enlace tiene una moneda, dar Zcoin al propietario
      if (link.hasCoin) {
        const user = await this.getUser(link.userId);
        if (user) {
          user.zcoinBalance += 1; // Dar 1 Zcoin por clic en link con moneda
          this.users.set(user.id, user);
        }
      }
      
      // Actualizar estadísticas de rendimiento
      this.updateLinkPerformance(linkId, {
        clicks: 1,
        uniqueVisitors: 1,
        completedVisits: 0,
        rewardsEarned: 0
      });
      
      // Registrar la visita para el sistema de reclamación de recompensas
      const visitResult = await this.registerVisit(linkId, ipAddress, userId);
      
      return {
        success: true,
        isValid: true,
        message: "Click recorded successfully",
        visitId: visitResult.visitId
      };
    } else {
      // Clic inválido, posiblemente fraudulento
      return {
        success: false,
        isValid: false,
        message: fraudCheckResult.reason || "Suspicious activity detected",
        fraudScore: fraudCheckResult.fraudScore
      };
    }
  }
  
  // Método auxiliar para actualizar estadísticas de rendimiento
  private async updateLinkPerformance(
    linkId: number,
    stats: {
      clicks: number;
      uniqueVisitors: number;
      completedVisits: number;
      rewardsEarned: number;
    }
  ): Promise<void> {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Normalizar a las 00:00:00 del día actual
    
    // Buscar o crear rendimiento para el día actual
    let performances = this.linkPerformances.get(linkId) || [];
    let todayPerformance = performances.find(p => {
      const perfDate = new Date(p.date);
      return perfDate.getDate() === today.getDate() && 
             perfDate.getMonth() === today.getMonth() && 
             perfDate.getFullYear() === today.getFullYear();
    });
    
    if (!todayPerformance) {
      // Crear un nuevo registro para el día actual
      const conversionRate = stats.clicks > 0 ? (stats.completedVisits / stats.clicks * 100).toFixed(2) : "0";
      todayPerformance = {
        id: performances.length + 1,
        linkId,
        date: today,
        clicks: stats.clicks,
        uniqueVisitors: stats.uniqueVisitors,
        completedVisits: stats.completedVisits,
        rewardsEarned: stats.rewardsEarned,
        conversionRate,
        createdAt: new Date()
      };
      performances.push(todayPerformance);
    } else {
      // Actualizar el registro existente
      todayPerformance.clicks += stats.clicks;
      todayPerformance.uniqueVisitors += stats.uniqueVisitors;
      todayPerformance.completedVisits += stats.completedVisits;
      todayPerformance.rewardsEarned += stats.rewardsEarned;
      
      // Recalcular la tasa de conversión
      const conversionRate = todayPerformance.clicks > 0 
        ? (todayPerformance.completedVisits / todayPerformance.clicks * 100).toFixed(2) 
        : "0";
      todayPerformance.conversionRate = conversionRate;
    }
    
    // Guardar las actualizaciones
    this.linkPerformances.set(linkId, performances);
  }
  
  // Dashboard de rendimiento
  async getLinkPerformance(
    linkId: number,
    startDate?: Date,
    endDate?: Date
  ): Promise<LinkPerformance[]> {
    const performances = this.linkPerformances.get(linkId) || [];
    
    if (!startDate && !endDate) {
      return performances;
    }
    
    return performances.filter(perf => {
      const date = new Date(perf.date);
      
      if (startDate && endDate) {
        return date >= startDate && date <= endDate;
      } else if (startDate) {
        return date >= startDate;
      } else if (endDate) {
        return date <= endDate;
      }
      
      return true;
    });
  }
  
  async getLinkPerformanceSummary(
    userId: number,
    period: 'day' | 'week' | 'month' | 'year' = 'week'
  ): Promise<{
    totalClicks: number;
    totalUniqueVisitors: number;
    totalCompletedVisits: number;
    totalRewardsEarned: number;
    averageConversionRate: number;
    topPerformingLinks: Array<{
      linkId: number;
      name: string;
      clicks: number;
      conversionRate: number;
    }>;
    performanceByDate: Array<{
      date: Date;
      clicks: number;
      uniqueVisitors: number;
      completedVisits: number;
    }>;
  }> {
    // Obtener todos los enlaces del usuario
    const userLinks = await this.getUserReferralLinks(userId);
    
    // Determinar la fecha de inicio según el período
    const startDate = new Date();
    switch (period) {
      case 'day':
        startDate.setDate(startDate.getDate() - 1);
        break;
      case 'week':
        startDate.setDate(startDate.getDate() - 7);
        break;
      case 'month':
        startDate.setMonth(startDate.getMonth() - 1);
        break;
      case 'year':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
    }
    
    // Inicializar el resumen
    let totalClicks = 0;
    let totalUniqueVisitors = 0;
    let totalCompletedVisits = 0;
    let totalRewardsEarned = 0;
    let totalConversionRate = 0;
    
    const performanceByDate = new Map<string, {
      date: Date;
      clicks: number;
      uniqueVisitors: number;
      completedVisits: number;
    }>();
    
    const linksPerformance: Array<{
      linkId: number;
      name: string;
      clicks: number;
      conversionRate: number;
    }> = [];
    
    // Procesar el rendimiento de cada enlace
    for (const link of userLinks) {
      const performances = await this.getLinkPerformance(link.id, startDate);
      
      if (performances.length === 0) {
        continue;
      }
      
      let linkTotalClicks = 0;
      let linkTotalCompletedVisits = 0;
      
      for (const perf of performances) {
        // Acumular totales
        totalClicks += perf.clicks;
        totalUniqueVisitors += perf.uniqueVisitors;
        totalCompletedVisits += perf.completedVisits;
        totalRewardsEarned += perf.rewardsEarned;
        
        linkTotalClicks += perf.clicks;
        linkTotalCompletedVisits += perf.completedVisits;
        
        // Agrupar por fecha
        const dateStr = perf.date.toISOString().split('T')[0];
        const dateData = performanceByDate.get(dateStr) || {
          date: new Date(perf.date),
          clicks: 0,
          uniqueVisitors: 0,
          completedVisits: 0
        };
        
        dateData.clicks += perf.clicks;
        dateData.uniqueVisitors += perf.uniqueVisitors;
        dateData.completedVisits += perf.completedVisits;
        
        performanceByDate.set(dateStr, dateData);
      }
      
      // Calcular la tasa de conversión para este enlace
      const linkConversionRate = linkTotalClicks > 0 
        ? (linkTotalCompletedVisits / linkTotalClicks * 100) 
        : 0;
      
      // Agregar a la lista de enlaces
      linksPerformance.push({
        linkId: link.id,
        name: link.name,
        clicks: linkTotalClicks,
        conversionRate: linkConversionRate
      });
    }
    
    // Calcular la tasa de conversión promedio
    const averageConversionRate = totalClicks > 0 
      ? (totalCompletedVisits / totalClicks * 100) 
      : 0;
    
    // Ordenar los enlaces por número de clics (de mayor a menor)
    const topPerformingLinks = linksPerformance
      .sort((a, b) => b.clicks - a.clicks)
      .slice(0, 5); // Obtener los 5 principales
    
    // Ordenar el rendimiento por fecha (de más reciente a más antiguo)
    const sortedPerformanceByDate = Array.from(performanceByDate.values())
      .sort((a, b) => b.date.getTime() - a.date.getTime());
    
    return {
      totalClicks,
      totalUniqueVisitors,
      totalCompletedVisits,
      totalRewardsEarned,
      averageConversionRate,
      topPerformingLinks,
      performanceByDate: sortedPerformanceByDate
    };
  }
}

export const storage = new MemStorage();

// Inicializar el sistema anti-fraude después de crear la instancia de storage
// Importar aquí para evitar dependencias circulares
import { antiFraudSystem } from './antifraud';
(storage as any).antiFraudSystem = antiFraudSystem;
