import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import ReferralListing from "@/pages/referral-listing";
import Quests from "@/pages/quests";
import ReferralLink from "@/pages/referral-link";
import Performance from "@/pages/performance";
import AddReferral from "@/pages/add-referral";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/referral-listing" component={ReferralListing} />
      <Route path="/quests" component={Quests} />
      <Route path="/referral-link" component={ReferralLink} />
      <Route path="/performance" component={Performance} />
      <Route path="/add-referral" component={AddReferral} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
