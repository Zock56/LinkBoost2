import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { BottomNav } from "@/components/layout/bottom-nav";
import { Header } from "@/components/layout/header";
import { CircuitBackground } from "@/components/ui/circuit-background";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Download } from "lucide-react";

export default function AddReferral() {
  const [referralLink, setReferralLink] = useState("");
  const [, setLocation] = useLocation();
  
  // Fetch user data to get current number of links
  const { data: userData } = useQuery({
    queryKey: ['/api/users/me'],
  });
  
  const { data: referralLinks } = useQuery({
    queryKey: ['/api/referral-links'],
  });
  
  // Calculate which number link this is (1/3, 2/3, or 3/3)
  const currentLinks = referralLinks?.length || 0;
  const linkNumber = currentLinks + 1;
  
  // Handle form submission
  const mutation = useMutation({
    mutationFn: async (link: string) => {
      return apiRequest('/api/referral-links', {
        method: 'POST',
        body: JSON.stringify({
          name: `Link ${linkNumber}`, // Nombre temporal, en un caso real se extraería de la URL
          userId: userData?.id || 1,
          clicks: 0,
          recentClicks: 0,
          rank: 999, // Ranking inicial bajo
          totalLinks: 1000, // Número total de links en el sistema
          iconType: "blue"
        })
      });
    },
    onSuccess: () => {
      // Invalidate referral links query to refetch data
      queryClient.invalidateQueries({ queryKey: ['/api/referral-links'] });
      // Redirect back to dashboard
      setLocation('/');
    }
  });
  
  const handleSubmit = () => {
    if (referralLink.trim()) {
      mutation.mutate(referralLink);
    }
  };
  
  const handleGetLink = () => {
    // Simula la obtención de un link desde chats de Telegram
    // En una implementación real, esto interactuaría con la API de Telegram
    setReferralLink("https://t.me/example_bot?start=referral123");
  };
  
  return (
    <div className="circuit-bg min-h-screen pb-16 max-w-md mx-auto">
      <CircuitBackground />
      
      <Header title="Add Referral" />
      
      <div className="p-4">
        <div className="bg-dark-card rounded-xl overflow-hidden p-5 mb-4">
          <div className="flex items-center mb-5">
            <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white text-xl font-bold mr-3">
              A
            </div>
            <div>
              <h2 className="font-medium">Hi {userData?.username || 'User'}, you are adding your</h2>
              <p className="text-lg font-semibold">{linkNumber}/3 Referral link</p>
            </div>
          </div>
          
          <h3 className="text-lg font-medium mb-2">Paste your referral link</h3>
          <p className="text-gray-400 text-sm mb-4">
            You can also share referral links from your app directly to @linkboost_bot chat, 
            <span className="text-blue-400 ml-1 cursor-pointer">how it works?</span>
          </p>
          
          <div className="bg-yellow-500/10 border border-yellow-500/30 text-yellow-500 p-3 rounded-md mb-4 text-sm">
            <p className="flex items-center">
              <span className="mr-2">👆</span>
              Ensure that simply opening the link you are adding is enough for referral activation.
            </p>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium mb-1.5">Referral link</label>
            <Input 
              value={referralLink}
              onChange={(e) => setReferralLink(e.target.value)}
              placeholder="Enter your referral link"
              className="bg-white/5 border-gray-700"
            />
          </div>
          
          <Button 
            variant="outline" 
            className="w-full mb-4 bg-transparent border-blue-500 text-blue-400 hover:bg-blue-500/10 flex items-center justify-center"
            onClick={handleGetLink}
          >
            <Download className="h-4 w-4 mr-2" />
            Open chats to get a link
          </Button>
          
          <Button 
            className="w-full bg-blue-500 hover:bg-blue-600 text-white"
            onClick={handleSubmit}
            disabled={!referralLink.trim() || mutation.isPending}
          >
            {mutation.isPending ? "Submitting..." : "Submit"}
          </Button>
        </div>
      </div>
      
      <BottomNav />
    </div>
  );
}