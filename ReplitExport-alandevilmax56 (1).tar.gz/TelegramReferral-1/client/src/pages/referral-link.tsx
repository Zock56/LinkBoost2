import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNav } from "@/components/layout/bottom-nav";
import { CircuitBackground } from "@/components/ui/circuit-background";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ZcoinLogo } from "@/components/ui/zcoin-logo";
import { Copy, UserPlus } from "lucide-react";
import { animateRepGain } from "@/lib/utils";
import { ReferralLink as ReferralLinkType } from "@/components/referral/referral-link-item";

export default function ReferralLink() {
  // Fetch user data and referral links from API
  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ['/api/users/me'],
  });

  const { data: referralLinks, isLoading: linksLoading } = useQuery({
    queryKey: ['/api/referral-links'],
  });

  const handleCopyLink = () => {
    // In a real app, this would copy the link to clipboard
    const linkText = "@linkboost_bot/app?startapp=6530524782";
    navigator.clipboard.writeText(linkText)
      .then(() => {
        alert("Link copied to clipboard!");
      })
      .catch((err) => {
        console.error("Could not copy text: ", err);
      });
  };

  const handleInviteFriends = () => {
    // In a real app, this would open a share dialog
    animateRepGain(50);
  };

  // Use placeholder values if data is still loading
  const user = userData || {};
  const friendsInvited = userLoading ? 0 : user.friendsInvited || 13;
  const totalRepFromFriends = userLoading ? 0 : user.totalRepFromFriends || 650;
  const links = linksLoading ? [] : (referralLinks || []) as ReferralLinkType[];

  return (
    <div className="circuit-bg min-h-screen pb-16 max-w-md mx-auto">
      <CircuitBackground />
      
      <Header title="LinkBoost" />
      
      <Card className="bg-dark-card mx-4 rounded-xl overflow-hidden border-none">
        <div className="px-4 py-5">
          <h2 className="text-2xl font-semibold mb-1">LinkBoost</h2>
          <div className="text-gray-300 text-sm uppercase">
            1 LINK - ALWAYS UP-TO-DATE MINI-APPS<br />
            <span className="text-zcoin-blue">+ BOOST FOR YOUR REP</span>
          </div>
        </div>

        <div className="px-4 pb-6">
          {links.map((link, index) => (
            <div 
              key={link.id}
              className="flex items-center justify-between bg-dark-card-hover p-2 rounded-lg mb-3"
            >
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-gradient-to-br from-zcoin-blue to-zcoin-blue/20 flex items-center justify-center mr-2">
                  <ZcoinLogo size="sm" />
                </div>
                <span className="text-gray-300 text-sm">{link.name}</span>
                {link.isOverlinked && (
                  <div className="ml-2 px-1.5 py-0.5 bg-yellow-500/20 text-yellow-500 text-xs rounded-full flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-0.5 h-3 w-3"
                    >
                      <circle cx="12" cy="12" r="10" />
                      <line x1="12" y1="8" x2="12" y2="12" />
                      <line x1="12" y1="16" x2="12.01" y2="16" />
                    </svg>
                    Overlinked
                  </div>
                )}
              </div>
              <span className="text-gray-400 text-sm">#{link.rank}</span>
            </div>
          ))}

          <div className="flex items-center justify-between bg-dark-card-hover p-2 rounded-lg mb-3">
            <div className="flex items-center">
              <div className="flex items-center space-x-1 mr-1.5">
                <span className="text-sm">Your LinkBoost Link:</span>
              </div>
              <div className="bg-zcoin-blue/10 text-zcoin-blue rounded-md px-1.5 py-1 text-xs font-mono">
                @linkboost_bot/app?startapp=6530524782
              </div>
            </div>
            <button 
              className="h-7 w-7 bg-dark-card-hover rounded-md flex items-center justify-center ml-1"
              onClick={handleCopyLink}
            >
              <Copy className="h-4 w-4 text-gray-300" />
            </button>
          </div>

          <h3 className="text-xl font-semibold mt-6 mb-3">Single link to invite friends:</h3>
          <ul className="space-y-2 text-sm mb-5">
            <li className="flex items-start">
              <span className="text-zcoin-gold mr-2">•</span>
              <span>If ALL the links will be opened, you and your friend will get <span className="text-zcoin-blue font-medium">+50 REP</span></span>
            </li>
            <li className="flex items-start">
              <span className="text-zcoin-gold mr-2">•</span>
              <span>Share single link to invite friends to the actual apps you need right now!</span>
            </li>
            <li className="flex items-start">
              <span className="text-zcoin-gold mr-2">•</span>
              <span>Friends invited: <span className="text-zcoin-blue font-medium">{friendsInvited} (+{totalRepFromFriends} REP)</span></span>
            </li>
          </ul>

          <Button 
            onClick={handleInviteFriends}
            className="w-full bg-zcoin-blue text-white font-medium py-3 px-3 rounded-lg shadow flex items-center justify-center hover:bg-zcoin-blue/90"
          >
            <UserPlus className="h-5 w-5 mr-2" />
            <span>Invite friends</span>
          </Button>
        </div>
      </Card>
      
      <BottomNav />
    </div>
  );
}
