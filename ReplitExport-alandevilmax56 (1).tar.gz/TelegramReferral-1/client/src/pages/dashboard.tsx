import { useQuery } from "@tanstack/react-query";
import { BottomNav } from "@/components/layout/bottom-nav";
import { Header } from "@/components/layout/header";
import { CircuitBackground } from "@/components/ui/circuit-background";
import { ShareBanner } from "@/components/referral/share-banner";
import { ReputationCard } from "@/components/referral/reputation-card";
import { NavigationTabs } from "@/components/referral/navigation-tabs";
import { ReferralLinkItem } from "@/components/referral/referral-link-item";
import { BoostButton } from "@/components/referral/boost-button";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { BarChart3, ChevronRight } from "lucide-react";
import { useLocation } from "wouter";

export default function Dashboard() {
  const { toast } = useToast();
  const [,navigate] = useLocation();
  
  // Fetch user data and referral links from API
  const { data: userData, isLoading: userLoading } = useQuery<any>({
    queryKey: ['/api/users/me'],
  });

  const { data: referralLinks, isLoading: linksLoading } = useQuery<any[]>({
    queryKey: ['/api/referral-links'],
  });

  const handleShareLink = async () => {
    try {
      // Hacer una llamada a la API para compartir el enlace
      const response = await fetch('/api/share-link', {
        method: 'POST'
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: "Links Shared!",
          description: `You've earned ${data.zcoinGained} Zcoins`,
          variant: "default",
        });
        
        // Actualizar los datos del usuario
        queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
      }
    } catch (error) {
      console.error("Error al compartir enlace:", error);
      toast({
        title: "Error",
        description: "Could not share links",
        variant: "destructive",
      });
    }
  };

  // Use placeholder values if data is still loading
  const userRank = userLoading ? 0 : userData?.rank || 305;
  const todayRep = userLoading ? 0 : userData?.todayRep || 70;
  const links = linksLoading ? [] : referralLinks || [] as any[];

  // Crear espacios vacíos para completar hasta 3 links
  const emptySlots = Math.max(0, 3 - (Array.isArray(links) ? links.length : 0));
  const emptySlotItems = Array(emptySlots).fill(0).map((_, index) => ({
    id: `empty-${index}`,
    isEmpty: true
  }));

  return (
    <div className="circuit-bg min-h-screen pb-16 max-w-md mx-auto">
      <CircuitBackground />
      
      <Header title="LinkBoost" showBackButton={false} />
      
      <ShareBanner onClick={handleShareLink} />
      
      <ReputationCard rank={userRank} todayRep={todayRep} />
      
      <NavigationTabs />
      
      <div className="mt-6 px-4">
        {/* Links existentes */}
        {Array.isArray(links) && links.map((link: any) => (
          <ReferralLinkItem key={link.id} link={link} />
        ))}
        
        {/* Botón de añadir link de referencia */}
        {emptySlots > 0 && (
          <div 
            onClick={() => navigate("/add-referral")}
            className="bg-gray-100/5 rounded-xl mb-3 overflow-hidden p-4 flex items-center justify-center cursor-pointer hover:bg-gray-100/10 transition-colors"
          >
            <div className="h-8 w-8 rounded-full bg-gray-700 flex items-center justify-center mr-2">
              <span className="text-white text-lg">+</span>
            </div>
            <span className="text-gray-300">Add referral link</span>
          </div>
        )}
      </div>

      <div className="text-center text-gray-300 text-sm px-6 mt-2 mb-4">
        You can add up to 3 referral links, boost your links positions to get more clicks.
      </div>

      <BoostButton />
      
      <div className="mt-6 mb-10">
        <div
          className="flex items-center justify-between bg-gradient-to-r from-zcoin-blue/20 to-zcoin-purple/20 rounded-lg p-4 cursor-pointer"
          onClick={() => navigate("/performance")}
        >
          <div className="flex items-center">
            <BarChart3 className="h-5 w-5 text-zcoin-blue mr-2" />
            <div>
              <h3 className="font-semibold">Performance Dashboard</h3>
              <p className="text-xs text-gray-400">Track your link analytics</p>
            </div>
          </div>
          <ChevronRight className="h-5 w-5 text-gray-400" />
        </div>
      </div>
      
      <BottomNav />
    </div>
  );
}
