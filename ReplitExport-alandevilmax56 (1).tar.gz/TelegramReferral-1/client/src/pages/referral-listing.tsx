import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNav } from "@/components/layout/bottom-nav";
import { CircuitBackground } from "@/components/ui/circuit-background";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BoostButton } from "@/components/referral/boost-button";
import { ZcoinLogo } from "@/components/ui/zcoin-logo";
import { animateRepGain } from "@/lib/utils";

interface ReferralAppItem {
  id: number;
  name: string;
  iconType: "blue" | "purple" | "gold" | "red";
  rank?: number;
  totalLinks?: number;
  forUser?: string;
  repAmount?: number;
  fromUser?: string;
}

export default function ReferralListing() {
  // Fetch available referral links from API
  const { data: availableLinks, isLoading } = useQuery({
    queryKey: ['/api/available-links'],
  });

  const handleOpenApp = (linkId: number) => {
    // In a real app, this would open the target app
    animateRepGain(5);
  };

  const links: ReferralAppItem[] = isLoading ? [] : availableLinks || [
    {
      id: 1,
      name: "DreamStation App",
      iconType: "blue",
      rank: 794,
      totalLinks: 7221,
      forUser: "Zock"
    },
    {
      id: 2,
      name: "TON YouTube",
      iconType: "red",
      repAmount: 5,
      fromUser: "Rida02"
    }
  ];

  return (
    <div className="circuit-bg min-h-screen pb-16 max-w-md mx-auto">
      <CircuitBackground />

      <Header title="Referral Assistant" />

      <Card className="bg-dark-card mx-4 rounded-xl overflow-hidden border-none">
        <div className="px-4 py-5">
          <h2 className="text-2xl font-semibold mb-1">Referral Links Listing</h2>
          <div className="flex items-center justify-between">
            <p className="text-gray-300 text-sm">Boost your links ranking by opening other people apps</p>
            <a href="#" className="text-zcoin-blue text-sm">HOW IT WORKS?</a>
          </div>
        </div>

        <div className="border-t border-gray-700/50">
          <div className="flex items-center justify-between px-4 py-3">
            <h3 className="font-medium text-gray-300">REFERRAL LINKS:</h3>
            <a href="#" className="text-green-500 text-sm font-medium">PROMOTE MY LINKS</a>
          </div>

          <div className="space-y-1">
            {links.map((link) => (
              <div 
                key={link.id}
                className={`flex items-center justify-between px-4 py-3 hover:bg-dark-card-hover transition-colors ${link.repAmount ? 'bg-zcoin-blue/5 border-l-4 border-zcoin-blue' : ''}`}
              >
                <div className="flex items-center">
                  <div className="flex-shrink-0 mr-3">
                    <div className={`h-10 w-10 rounded-full ${
                      link.iconType === "blue" ? "bg-gradient-to-br from-zcoin-blue to-zcoin-blue/20" :
                      link.iconType === "purple" ? "bg-gradient-to-br from-zcoin-purple to-zcoin-purple/20" :
                      link.iconType === "gold" ? "bg-gradient-to-br from-zcoin-gold to-zcoin-gold/20" :
                      "bg-red-500/20"
                    } flex items-center justify-center`}>
                      <ZcoinLogo size="sm" />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center">
                      <h3 className="font-medium">{link.name}</h3>
                    </div>
                    {link.forUser && (
                      <div className="text-gray-400 text-xs">for {link.forUser}</div>
                    )}
                    {link.repAmount && (
                      <div className="text-zcoin-blue text-xs font-medium">+{link.repAmount} Zcoin from {link.fromUser}</div>
                    )}
                  </div>
                </div>
                {link.rank ? (
                  <div className="flex items-center text-right text-sm">
                    <span className="mr-2 text-zcoin-blue font-medium">{link.rank}th</span>
                    <span className="text-gray-400 text-xs">/ {link.totalLinks} links</span>
                  </div>
                ) : (
                  <Button 
                    onClick={() => handleOpenApp(link.id)}
                    className="bg-zcoin-blue rounded-lg text-white px-4 py-1.5 text-sm hover:bg-zcoin-blue/90"
                  >
                    Open
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>
      </Card>

      <div className="mt-6">
        <BoostButton />
      </div>

      <BottomNav />
    </div>
  );
}