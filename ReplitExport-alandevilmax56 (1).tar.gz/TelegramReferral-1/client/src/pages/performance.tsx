import React, { useEffect, useRef, useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Header } from "@/components/layout/header";
import { BottomNav } from "@/components/layout/bottom-nav";
import { getQueryFn } from '@/lib/queryClient';
import { useQuery } from '@tanstack/react-query';
import { useToast } from "@/hooks/use-toast";

interface PerformanceData {
  date: string;
  clicks: number;
  uniqueVisitors: number;
  completedVisits: number;
}

interface LinkPerformance {
  linkId: number;
  name: string;
  clicks: number;
  conversionRate: number;
}

interface PerformanceSummary {
  totalClicks: number;
  totalUniqueVisitors: number;
  totalCompletedVisits: number;
  totalRewardsEarned: number;
  averageConversionRate: number;
  topPerformingLinks: LinkPerformance[];
  performanceByDate: PerformanceData[];
}

export default function Performance() {
  const { toast } = useToast();
  const [activePeriod, setActivePeriod] = useState<'day' | 'week' | 'month' | 'year'>('week');
  const [socketConnected, setSocketConnected] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  
  const { data, isLoading, error, refetch } = useQuery<PerformanceSummary>({
    queryKey: ['/api/performance/summary', activePeriod],
    queryFn: getQueryFn({ on401: 'returnNull' }),
  });

  // Usamos un valor predeterminado que coincida con la interfaz PerformanceSummary
  const defaultData: PerformanceSummary = {
    totalClicks: 0,
    totalUniqueVisitors: 0,
    totalCompletedVisits: 0,
    totalRewardsEarned: 0,
    averageConversionRate: 0,
    topPerformingLinks: [],
    performanceByDate: []
  };
  
  const performanceData = data || defaultData;

  // Efecto para conectar WebSocket
  useEffect(() => {
    // Establecer conexión WebSocket
    const connectWebSocket = () => {
      try {
        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        const wsUrl = `${protocol}//${window.location.host}/ws`;
        
        const socket = new WebSocket(wsUrl);
        socketRef.current = socket;
        
        socket.addEventListener('open', () => {
          console.log('WebSocket connection established');
          setSocketConnected(true);
          toast({
            title: "Conectado",
            description: "Conexión en tiempo real establecida",
          });
        });
        
        socket.addEventListener('message', (event) => {
          try {
            const data = JSON.parse(event.data);
            
            if (data.type === 'performance_update') {
              // Refrescar datos
              refetch();
              toast({
                title: "Datos actualizados",
                description: "Información de rendimiento actualizada en tiempo real",
              });
            }
          } catch (error) {
            console.error('Error parsing WebSocket message:', error);
          }
        });
        
        socket.addEventListener('close', () => {
          console.log('WebSocket connection closed');
          setSocketConnected(false);
          
          // Intentar reconectar después de 5 segundos
          setTimeout(connectWebSocket, 5000);
        });
        
        socket.addEventListener('error', (event) => {
          console.error('WebSocket error:', event);
          setSocketConnected(false);
        });
      } catch (error) {
        console.error('Error establishing WebSocket connection:', error);
      }
    };
    
    connectWebSocket();
    
    // Limpiar conexión al desmontar
    return () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, [toast]);

  const formatPerformanceData = () => {
    if (!performanceData.performanceByDate) return [];
    
    return performanceData.performanceByDate.map(item => ({
      ...item,
      date: new Date(item.date).toLocaleDateString(),
    }));
  };
  
  const handlePeriodChange = (period: 'day' | 'week' | 'month' | 'year') => {
    setActivePeriod(period);
    toast({
      title: "Período cambiado",
      description: `Mostrando datos del último ${
        period === 'day' ? 'día' : 
        period === 'week' ? 'semana' : 
        period === 'month' ? 'mes' : 'año'
      }`,
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white circuit-bg pb-16">
      <Header title="Panel de Rendimiento" />
      
      <main className="container mx-auto px-4 py-4">
        {/* Conexión en tiempo real */}
        <div className={`mb-4 px-3 py-2 text-sm rounded-lg flex items-center ${socketConnected ? 'bg-green-900/30 text-green-500' : 'bg-orange-900/30 text-orange-500'}`}>
          <div className={`w-2 h-2 rounded-full mr-2 ${socketConnected ? 'bg-green-500' : 'bg-orange-500'}`}></div>
          <span>{socketConnected ? 'Actualizaciones en tiempo real activadas' : 'Esperando conexión en tiempo real...'}</span>
        </div>
        
        {/* Panel de Rendimiento */}
        <div className="zcoin-gradient p-1 rounded-xl shadow-xl mb-6">
          <div className="bg-slate-900 rounded-lg p-4">
            <h2 className="text-xl font-semibold mb-4">Resumen de Rendimiento</h2>
            
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="bg-slate-800 p-4 rounded-lg">
                <p className="text-blue-300 text-sm">Clics Totales</p>
                <p className="text-2xl font-bold">{performanceData.totalClicks}</p>
              </div>
              <div className="bg-slate-800 p-4 rounded-lg">
                <p className="text-blue-300 text-sm">Visitantes Únicos</p>
                <p className="text-2xl font-bold">{performanceData.totalUniqueVisitors}</p>
              </div>
              <div className="bg-slate-800 p-4 rounded-lg">
                <p className="text-blue-300 text-sm">Visitas Completadas</p>
                <p className="text-2xl font-bold">{performanceData.totalCompletedVisits}</p>
              </div>
              <div className="bg-slate-800 p-4 rounded-lg">
                <p className="text-blue-300 text-sm">Recompensas Ganadas</p>
                <p className="text-2xl font-bold">{performanceData.totalRewardsEarned}</p>
              </div>
            </div>
            
            {/* Gráfico de Rendimiento */}
            <div className="bg-slate-800 p-4 rounded-lg mb-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                <h3 className="text-lg font-medium">Rendimiento en el Tiempo</h3>
                <div className="flex space-x-2 mt-2 md:mt-0">
                  <button 
                    onClick={() => handlePeriodChange('day')}
                    className={`px-3 py-1 text-sm rounded-md transition-colors ${activePeriod === 'day' ? 'bg-blue-900' : 'bg-slate-700 hover:bg-blue-900/70'}`}
                  >
                    Día
                  </button>
                  <button 
                    onClick={() => handlePeriodChange('week')}
                    className={`px-3 py-1 text-sm rounded-md transition-colors ${activePeriod === 'week' ? 'bg-blue-900' : 'bg-slate-700 hover:bg-blue-900/70'}`}
                  >
                    Semana
                  </button>
                  <button 
                    onClick={() => handlePeriodChange('month')}
                    className={`px-3 py-1 text-sm rounded-md transition-colors ${activePeriod === 'month' ? 'bg-blue-900' : 'bg-slate-700 hover:bg-blue-900/70'}`}
                  >
                    Mes
                  </button>
                  <button 
                    onClick={() => handlePeriodChange('year')}
                    className={`px-3 py-1 text-sm rounded-md transition-colors ${activePeriod === 'year' ? 'bg-blue-900' : 'bg-slate-700 hover:bg-blue-900/70'}`}
                  >
                    Año
                  </button>
                </div>
              </div>
              
              <div className="h-60 w-full">
                {isLoading ? (
                  <div className="h-full w-full flex items-center justify-center">
                    <div className="zcoin-gradient w-10 h-10 rounded-full animate-pulse"></div>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={formatPerformanceData()}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="date" stroke="#94a3b8" />
                      <YAxis stroke="#94a3b8" />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155' }} 
                        labelStyle={{ color: '#f1f5f9' }}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="clicks" 
                        name="Clics"
                        stroke="#3b82f6" 
                        fill="#3b82f6" 
                        activeDot={{ r: 8 }} 
                      />
                      <Line 
                        type="monotone" 
                        dataKey="uniqueVisitors" 
                        name="Visitantes"
                        stroke="#8b5cf6" 
                        fill="#8b5cf6" 
                      />
                      <Line 
                        type="monotone" 
                        dataKey="completedVisits" 
                        name="Completados"
                        stroke="#10b981" 
                        fill="#10b981" 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>
            
            {/* Enlaces de Mejor Rendimiento */}
            <div className="bg-slate-800 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-4">Enlaces de Mejor Rendimiento</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-blue-300 text-left">
                      <th className="pb-2">Nombre</th>
                      <th className="pb-2">Clics</th>
                      <th className="pb-2">Tasa de Conversión</th>
                    </tr>
                  </thead>
                  <tbody>
                    {isLoading ? (
                      <tr>
                        <td colSpan={3} className="text-center py-4">
                          <div className="flex justify-center">
                            <div className="zcoin-gradient w-8 h-8 rounded-full animate-pulse"></div>
                          </div>
                        </td>
                      </tr>
                    ) : performanceData.topPerformingLinks && performanceData.topPerformingLinks.length > 0 ? (
                      performanceData.topPerformingLinks.map((link) => (
                        <tr key={link.linkId}>
                          <td className="py-2">{link.name}</td>
                          <td className="py-2">{link.clicks}</td>
                          <td className="py-2">{link.conversionRate.toFixed(1)}%</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={3} className="text-center py-4">
                          No hay datos disponibles
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
}