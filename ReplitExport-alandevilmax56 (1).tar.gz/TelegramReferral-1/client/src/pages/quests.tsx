import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { BottomNav } from "@/components/layout/bottom-nav";
import { CircuitBackground } from "@/components/ui/circuit-background";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BoostButton } from "@/components/referral/boost-button";
import { animateRepGain } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Play, Zap } from "lucide-react";
import { ZcoinLogo } from "@/components/ui/zcoin-logo";
import { useToast } from "@/hooks/use-toast";

export default function Quests() {
  const { toast } = useToast();
  const [watching, setWatching] = useState(false);

  // Fetch quests and user data from API
  const { data: quests, isLoading: questsLoading } = useQuery({
    queryKey: ['/api/quests'],
  });

  const { data: user } = useQuery({
    queryKey: ['/api/users/me'],
  });

  // Mutation to claim quest
  const claimMutation = useMutation({
    mutationFn: async (questId: number) => {
      return apiRequest(`/api/quests/${questId}/claim`, {
        method: 'POST'
      });
    },
    onSuccess: (data) => {
      if (data.success) {
        if (data.zcoinReward) {
          toast({
            title: "¡Recompensa recibida!",
            description: `Has ganado ${data.reward} Zcoin y ${data.zcoinReward} Zcoins`,
          });
          animateRepGain(data.reward);
        } else {
          toast({
            title: "¡Recompensa recibida!",
            description: `Has ganado ${data.reward} Zcoin`,
          });
          animateRepGain(data.reward);
        }

        // Invalidate relevant queries
        queryClient.invalidateQueries({ queryKey: ['/api/quests'] });
        queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
      } else {
        toast({
          title: "Error",
          description: "Ya has reclamado esta misión hoy.",
          variant: "destructive"
        });
      }
    }
  });

  const handleClaimQuest = (questId: number) => {
    claimMutation.mutate(questId);
  };

  const handleWatchAd = (questId: number) => {
    setWatching(true);

    // Simular ver un anuncio (en una implementación real se mostraría un anuncio)
    setTimeout(() => {
      setWatching(false);
      handleClaimQuest(questId);
    }, 2000);
  };

  // Mapear datos de la API a formato de UI
  const formatQuestData = (apiQuests) => {
    if (!apiQuests || !Array.isArray(apiQuests)) return [];

    return apiQuests.map(quest => {
      // Crear un arreglo de niveles basado en el repReward
      // Esto es simplificado y se debería adaptar a la lógica real de niveles
      const levels = [quest.repReward];
      for (let i = 1; i < 5; i++) {
        levels.push(quest.repReward * (1 + i * 0.5));
      }

      return {
        ...quest,
        levels,
        currentLevel: 0
      };
    });
  };

  const questsList = formatQuestData(quests);

  return (
    <div className="circuit-bg min-h-screen pb-16 max-w-md mx-auto">
      <CircuitBackground />

      <Header title="LinkBoost" />

      <Card className="bg-dark-card mx-4 rounded-xl overflow-hidden border-none">
        <div className="px-4 py-5">
          <h2 className="text-2xl font-semibold mb-1">Quests</h2>
          <div className="flex items-center justify-between">
            <p className="text-gray-300 text-sm">Completa misiones para ganar Zcoin:</p>
            <a href="#" className="text-zcoin-blue text-sm">¿CÓMO FUNCIONA?</a>
          </div>
        </div>

        <div className="border-t border-gray-700/50">
          <div className="px-4 py-3">
            <h3 className="font-medium text-gray-300">LISTA DE MISIONES:</h3>
          </div>

          {questsLoading ? (
            <div className="px-4 py-3 text-center text-gray-400">Cargando misiones...</div>
          ) : (
            <>
              {questsList.map((quest) => (
                <div key={quest.id} className="px-4 py-3 hover:bg-dark-card-hover transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-br from-zcoin-blue to-zcoin-purple flex items-center justify-center mr-3">
                        {quest.name.includes("Video") ? (
                          <Play className="h-5 w-5 text-white" />
                        ) : (
                          <Zap className="h-5 w-5 text-white" />
                        )}
                      </div>
                      <div>
                        <h3 className="font-medium">{quest.name}</h3>
                        <div className="flex items-center mt-1">
                          <span className="text-xs text-gray-300 mr-2">
                            Recompensa:
                          </span>
                          <span className="text-xs text-zcoin-blue font-medium">
                            {quest.repReward} Zcoin
                          </span>

                          {quest.zcoinReward && (
                            <>
                              <span className="mx-1 text-gray-500">+</span>
                              <div className="flex items-center">
                                <span className="text-xs text-yellow-500 font-medium mr-1">
                                  {quest.zcoinReward}
                                </span>
                                <ZcoinLogo size="sm" className="h-3 w-3" />
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {quest.name.includes("Video") ? (
                      <Button 
                        onClick={() => handleWatchAd(quest.id)}
                        className="bg-yellow-500 rounded-lg text-white px-4 py-1.5 text-sm hover:bg-yellow-600"
                        disabled={watching || claimMutation.isPending}
                      >
                        {watching ? "Viendo..." : "Ver anuncio"}
                      </Button>
                    ) : (
                      <Button 
                        onClick={() => handleClaimQuest(quest.id)}
                        className="bg-zcoin-blue rounded-lg text-white px-4 py-1.5 text-sm hover:bg-zcoin-blue/90"
                        disabled={claimMutation.isPending}
                      >
                        {claimMutation.isPending ? "Reclamando..." : "Reclamar"}
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </>
          )}

          <div className="px-4 py-5 text-center border-t border-gray-700/50">
            <p className="text-sm">
              Únete a nuestro <a href="#" className="text-zcoin-blue">chat de LinkBoost</a>,<br />
              sé activo para obtener Zcoin adicional
            </p>
            <div className="mt-2 flex items-center justify-center">
              <ZcoinLogo size="sm" className="mr-2" />
              <span className="text-sm font-medium">
                Balance actual: {user?.zcoinBalance || 0} Zcoins
              </span>
            </div>
          </div>
        </div>
      </Card>

      <div className="mt-6">
        <BoostButton />
      </div>

      <BottomNav />
    </div>
  );
}