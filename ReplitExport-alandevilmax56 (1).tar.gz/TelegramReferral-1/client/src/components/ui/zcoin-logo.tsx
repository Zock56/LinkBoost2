import { cn } from "@/lib/utils";

interface ZcoinLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  withBackground?: boolean;
  backgroundColor?: "blue" | "purple" | "gold";
}

export function ZcoinLogo({ 
  className, 
  size = "md", 
  withBackground = false,
  backgroundColor = "blue"
}: ZcoinLogoProps) {
  const sizeClasses = {
    sm: "h-6 w-6",
    md: "h-8 w-8",
    lg: "h-10 w-10"
  };
  
  const backgroundColorClasses = {
    blue: "from-zcoin-blue/80 to-zcoin-blue/20",
    purple: "from-zcoin-purple/80 to-zcoin-purple/20",
    gold: "from-zcoin-gold/80 to-zcoin-gold/20",
  };

  return (
    <div className={cn(
      withBackground && "rounded-full bg-gradient-to-br flex items-center justify-center border border-opacity-40",
      withBackground && backgroundColorClasses[backgroundColor],
      withBackground && backgroundColor === "gold" && "border-yellow-400",
      withBackground && backgroundColor === "blue" && "border-blue-400",
      withBackground && backgroundColor === "purple" && "border-purple-400",
      withBackground && {
        "h-8 w-8": size === "sm",
        "h-12 w-12": size === "md",
        "h-16 w-16": size === "lg"
      },
      className
    )}>
      <svg 
        viewBox="0 0 100 100" 
        className={cn(
          sizeClasses[size],
          className
        )}
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Fondo del logo con circuitos */}
        <circle cx="50" cy="50" r="45" fill="transparent" stroke="rgba(255,255,255,0.2)" strokeWidth="1" />
        
        {/* Circuitos de fondo */}
        <path 
          d="M25,30 L40,30 L45,35 L70,35 M30,50 L40,50 L50,60 L75,60 M20,70 L35,70 L40,65 L65,65" 
          stroke="rgba(255,255,255,0.3)" 
          strokeWidth="1" 
          fill="none"
          className="circuit-line"
        />
        
        {/* Letra Z con gradiente */}
        <defs>
          <linearGradient id="zGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00BFFF" />
            <stop offset="50%" stopColor="#CC33FF" />
            <stop offset="100%" stopColor="#FFD700" />
          </linearGradient>
        </defs>
        
        <path 
          d="M30,30 L70,30 L30,70 L70,70" 
          stroke="url(#zGradient)" 
          strokeWidth="10" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          fill="none" 
          className="pulse-effect"
        />
      </svg>
    </div>
  );
}
