import { cn } from "@/lib/utils";

interface CircuitBackgroundProps {
  className?: string;
}

export function CircuitBackground({ className }: CircuitBackgroundProps) {
  return (
    <div className={cn("fixed inset-0 pointer-events-none z-0", className)}>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.03]">
        <svg width="300" height="300" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" fill="none" stroke="#CC33FF" strokeWidth="2" className="circuit-line" />
          <circle cx="50" cy="50" r="40" fill="none" stroke="#00BFFF" strokeWidth="1" className="circuit-line" />
          <path d="M35 30L65 30L35 70L65 70Z" fill="none" stroke="#FFD700" strokeWidth="3" className="circuit-line" />
          {/* Circuit pattern elements */}
          <line x1="20" y1="50" x2="30" y2="50" stroke="#00BFFF" strokeWidth="1" className="circuit-line" />
          <line x1="70" y1="50" x2="80" y2="50" stroke="#00BFFF" strokeWidth="1" className="circuit-line" />
          <line x1="50" y1="20" x2="50" y2="30" stroke="#CC33FF" strokeWidth="1" className="circuit-line" />
          <line x1="50" y1="70" x2="50" y2="80" stroke="#CC33FF" strokeWidth="1" className="circuit-line" />
          {/* Data nodes */}
          <circle cx="30" cy="50" r="2" fill="#00BFFF" />
          <circle cx="70" cy="50" r="2" fill="#00BFFF" />
          <circle cx="50" cy="30" r="2" fill="#CC33FF" />
          <circle cx="50" cy="70" r="2" fill="#CC33FF" />
        </svg>
      </div>
    </div>
  );
}
