import { BarChart3, Home, User } from "lucide-react";
import { useLocation } from "wouter";

export function BottomNav() {
  const [location, navigate] = useLocation();

  const handleNavigation = (path: string) => {
    navigate(path);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-dark-bg border-t border-gray-800 z-50">
      <div className="max-w-md mx-auto flex justify-between px-6 py-3">
        <button 
          className="flex flex-col items-center justify-center w-12"
          onClick={() => handleNavigation("/performance")}
        >
          <BarChart3 
            className={`h-5 w-5 ${location === "/performance" ? "text-zcoin-blue" : "text-gray-500"}`} 
          />
          <span className={`text-xs mt-1 ${location === "/performance" ? "text-zcoin-blue" : "text-gray-500"}`}>Stats</span>
        </button>
        
        <button 
          className="flex flex-col items-center justify-center w-12"
          onClick={() => handleNavigation("/")}
        >
          <div className={`h-10 w-10 rounded-full ${location === "/" 
            ? "bg-gradient-to-r from-zcoin-blue to-zcoin-purple" 
            : "bg-gray-800"} flex items-center justify-center`}
          >
            <Home className="h-5 w-5 text-white" />
          </div>
        </button>
        
        <button 
          className="flex flex-col items-center justify-center w-12"
          onClick={() => handleNavigation("/quests")}
        >
          <User 
            className={`h-5 w-5 ${location === "/quests" ? "text-zcoin-blue" : "text-gray-500"}`} 
          />
          <span className={`text-xs mt-1 ${location === "/quests" ? "text-zcoin-blue" : "text-gray-500"}`}>Profile</span>
        </button>
      </div>
    </nav>
  );
}
