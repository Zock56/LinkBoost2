import { ArrowLeft, ChevronDown, MoreVertical } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface HeaderProps {
  title: string;
  showBackButton?: boolean;
  className?: string;
}

export function Header({ title, showBackButton = true, className }: HeaderProps) {
  const [, navigate] = useLocation();

  const handleBack = () => {
    navigate("/");
  };

  return (
    <header className={cn("bg-dark-bg sticky top-0 z-50 border-b border-zcoin-blue/20", className)}>
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          {showBackButton && (
            <button 
              className="mr-2 text-white"
              onClick={handleBack}
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
          )}
          <h1 className="text-xl font-semibold">{title}</h1>
        </div>
        <div className="flex items-center space-x-2">
          <button className="text-white">
            <ChevronDown className="h-5 w-5" />
          </button>
          <button className="text-white">
            <MoreVertical className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
}
