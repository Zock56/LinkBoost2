import { Zap } from "lucide-react";
import { useLocation } from "wouter";

interface BoostButtonProps {
  onClick?: () => void;
  text?: string;
}

export function BoostButton({ onClick, text = "Boost My Links" }: BoostButtonProps) {
  const [, navigate] = useLocation();

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      navigate("/referral-listing");
    }
  };

  return (
    <div className="px-4 mb-6">
      <button 
        className="w-full bg-gradient-to-r from-zcoin-blue to-zcoin-purple text-white font-medium py-3 rounded-lg shadow-lg hover:opacity-90 transition-all flex items-center justify-center"
        onClick={handleClick}
      >
        <Zap className="h-5 w-5 mr-2" />
        <span>{text}</span>
      </button>
    </div>
  );
}
