import { ZcoinLogo } from "@/components/ui/zcoin-logo";

interface ShareBannerProps {
  amount?: number;
  onClick?: () => void;
}

export function ShareBanner({ amount = 3, onClick }: ShareBannerProps) {
  return (
    <div className="bg-zcoin-blue py-3 text-center font-semibold text-white">
      <button 
        className="flex items-center justify-center space-x-2 w-full"
        onClick={onClick}
      >
        <span>SHARE LINKBOOST LINK</span>
        <div className="bg-white/20 rounded-full px-2 py-0.5 text-sm flex items-center">
          <span className="mr-1">+{amount}</span>
          <ZcoinLogo size="sm" className="h-3.5 w-3.5" />
        </div>
      </button>
    </div>
  );
}
