import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card,
  CardContent,
  CardHeader,
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LineChart, 
  Line, 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer 
} from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { AppLogo, type AppIconType } from "@/components/referral/app-logo";
import { formatNumber } from "@/lib/utils";

interface PerformanceData {
  totalClicks: number;
  totalUniqueVisitors: number;
  totalCompletedVisits: number;
  totalRewardsEarned: number;
  averageConversionRate: number;
  topPerformingLinks: Array<{
    linkId: number;
    name: string;
    clicks: number;
    conversionRate: number;
  }>;
  performanceByDate: Array<{
    date: Date;
    clicks: number;
    uniqueVisitors: number;
    completedVisits: number;
  }>;
}

interface LinkPerformance {
  id: number;
  linkId: number;
  date: Date;
  clicks: number;
  uniqueVisitors: number;
  completedVisits: number;
  rewardsEarned: number;
  conversionRate: string;
  createdAt: Date;
}

export function PerformanceDashboard() {
  const [period, setPeriod] = useState<"day" | "week" | "month" | "year">("week");
  
  // Consulta inicial de datos a través de API REST
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/performance/summary", period],
    queryFn: async () => {
      const res = await fetch(`/api/performance/summary?period=${period}`);
      if (!res.ok) throw new Error("Failed to fetch performance data");
      const data = await res.json();
      
      // Convertir fechas de string a Date
      if (data.performanceByDate) {
        data.performanceByDate = data.performanceByDate.map((item: any) => ({
          ...item,
          date: new Date(item.date)
        }));
      }
      
      return data as PerformanceData;
    }
  });
  
  const chartData = useMemo(() => {
    if (!data?.performanceByDate || data.performanceByDate.length === 0) return [];
    
    return data.performanceByDate.map(item => ({
      date: item.date ? new Date(item.date).toLocaleDateString() : 'N/A',
      clicks: item.clicks || 0,
      visitors: item.uniqueVisitors || 0,
      conversions: item.completedVisits || 0,
    }));
  }, [data]);
  
  // Función para determinar el tipo de icono de la app
  const getAppIconType = (name: string): AppIconType => {
    if (name.toLowerCase().includes("bot")) return "bot";
    if (name.toLowerCase().includes("game")) return "game";
    if (name.toLowerCase().includes("music")) return "music";
    if (name.toLowerCase().includes("video")) return "video";
    if (name.toLowerCase().includes("chat")) return "chat";
    if (name.toLowerCase().includes("security")) return "security";
    return "default";
  };
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-center">Performance Dashboard</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardContent className="p-4">
            <Skeleton className="h-[300px] w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center p-4">
        <h2 className="text-2xl font-bold text-red-500">Error</h2>
        <p>Failed to load performance data. Please try again later.</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-center">Performance Dashboard</h2>
      
      <Tabs defaultValue={period} onValueChange={(value) => setPeriod(value as any)}>
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="day">Day</TabsTrigger>
          <TabsTrigger value="week">Week</TabsTrigger>
          <TabsTrigger value="month">Month</TabsTrigger>
          <TabsTrigger value="year">Year</TabsTrigger>
        </TabsList>
      </Tabs>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-xs text-muted-foreground uppercase">Total Clicks</p>
              <h3 className="text-2xl font-bold">{formatNumber(data?.totalClicks || 0)}</h3>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-xs text-muted-foreground uppercase">Unique Visitors</p>
              <h3 className="text-2xl font-bold">{formatNumber(data?.totalUniqueVisitors || 0)}</h3>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-xs text-muted-foreground uppercase">Conversions</p>
              <h3 className="text-2xl font-bold">{formatNumber(data?.totalCompletedVisits || 0)}</h3>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-xs text-muted-foreground uppercase">Zcoins Earned</p>
              <h3 className="text-2xl font-bold">{formatNumber(data?.totalRewardsEarned || 0)}</h3>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Trends</CardTitle>
          <CardDescription>
            Track how your links are performing over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="line">
            <TabsList className="mb-4">
              <TabsTrigger value="line">Line Chart</TabsTrigger>
              <TabsTrigger value="bar">Bar Chart</TabsTrigger>
            </TabsList>
            
            <TabsContent value="line">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="clicks" 
                      stroke="#8884d8" 
                      name="Clicks"
                      activeDot={{ r: 8 }} 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="visitors" 
                      stroke="#82ca9d" 
                      name="Visitors" 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="conversions" 
                      stroke="#ffc658" 
                      name="Conversions" 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
            
            <TabsContent value="bar">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="clicks" fill="#8884d8" name="Clicks" />
                    <Bar dataKey="visitors" fill="#82ca9d" name="Visitors" />
                    <Bar dataKey="conversions" fill="#ffc658" name="Conversions" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {/* Top Performing Links */}
      <Card>
        <CardHeader>
          <CardTitle>Top Performing Links</CardTitle>
          <CardDescription>
            Your best performing links based on click count
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {!data?.topPerformingLinks || data.topPerformingLinks.length === 0 ? (
              <p className="text-center text-muted-foreground">No data available yet</p>
            ) : (
              data.topPerformingLinks.map((link, index) => (
                <div key={link.linkId} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0">
                      <AppLogo 
                        size="sm" 
                        type={getAppIconType(link.name)} 
                        withBackground 
                        backgroundColor={index === 0 ? "gold" : index === 1 ? "purple" : "blue"}
                      />
                    </div>
                    <div>
                      <h4 className="font-medium">{link.name}</h4>
                      <p className="text-xs text-muted-foreground">
                        {formatNumber(link.clicks)} clicks • {typeof link.conversionRate === 'number' ? link.conversionRate.toFixed(1) : Number(link.conversionRate).toFixed(1)}% conversion
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-500">
                      #{index + 1}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Conversion Rate Card */}
      <Card>
        <CardContent className="pt-6">
          <div className="text-center">
            <p className="text-xs text-muted-foreground uppercase">Average Conversion Rate</p>
            <div className="flex justify-center items-center gap-2">
              <h3 className="text-4xl font-bold">{(data?.averageConversionRate || 0).toFixed(1)}%</h3>
              <div className="text-left">
                <p className="text-xs text-muted-foreground">of visitors</p>
                <p className="text-xs text-muted-foreground">claim rewards</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}