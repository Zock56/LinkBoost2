import { ArrowUp, Coins, AlertCircle, Trash2, ExternalLink, Gift } from "lucide-react";
import { cn } from "@/lib/utils";
import { AppLogo, AppIconType } from "./app-logo";
import { motion, PanInfo, useAnimation } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";

export interface ReferralLink {
  id: number;
  name: string;
  clicks: number;
  recentClicks?: number;
  rank: number;
  totalLinks: number;
  isOverlinked?: boolean;
  hasCoin?: boolean;
  iconType: "blue" | "purple" | "gold" | "red";
  appType?: AppIconType;
  // Para el sistema de reclamación de recompensas
  visitId?: number;
  canClaim?: boolean;
}

interface ReferralLinkItemProps {
  link: ReferralLink;
  className?: string;
}

export function ReferralLinkItem({ link, className }: ReferralLinkItemProps) {
  const controls = useAnimation();
  const { toast } = useToast();
  const [isDeleting, setIsDeleting] = useState(false);
  const [isClaiming, setIsClaiming] = useState(false);
  const [showClaim, setShowClaim] = useState(!!link.canClaim);
  const [visitId, setVisitId] = useState<number | undefined>(link.visitId);
  
  // Si no hay un tipo de app específico, asignar uno basado en el nombre
  const getAppType = (): AppIconType => {
    if (!link.appType) {
      const name = link.name.toLowerCase();
      if (name.includes('bot')) return 'bot';
      if (name.includes('game')) return 'game';
      if (name.includes('music')) return 'music';
      if (name.includes('video')) return 'video';
      if (name.includes('chat')) return 'chat';
      return 'default';
    }
    return link.appType;
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isDeleting) return;

    setIsDeleting(true);
    
    try {
      // En una implementación real, haríamos una llamada a la API aquí
      await fetch(`/api/referral-links/${link.id}`, {
        method: 'DELETE'
      });
      
      // Actualizar la lista de enlaces
      queryClient.invalidateQueries({ queryKey: ['/api/referral-links'] });
      
      toast({
        title: "Link deleted",
        description: `${link.name} has been removed from your links`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not delete link, please try again",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const openLink = async () => {
    // En una implementación real, esto abriría el enlace en Telegram
    // o mostraría un código QR/enlace para compartir
    try {
      // Registrar el clic y obtener visitId
      const response = await fetch('/api/record-click', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          linkId: link.id,
          metadata: { source: 'web-client' }
        }),
      });
      
      const data = await response.json();
      
      // Si el clic es válido y obtenemos un ID de visita, guardarlo
      if (data.success && data.isValid && data.visitId) {
        setVisitId(data.visitId);
        
        // Simulamos que el usuario ha abierto la aplicación después de unos segundos
        // En una aplicación real, esto sería manejado por eventos de Telegram
        setTimeout(async () => {
          // Marcar la visita como completada (usuario abrió la app)
          await fetch(`/api/mark-visited/${data.visitId}`, {
            method: 'POST'
          });
          
          // Mostrar el botón para reclamar la recompensa
          setShowClaim(true);
        }, 2000);
      }
      
      toast({
        title: "Link opened",
        description: `Opening ${link.name} referral link`,
      });
    } catch (error) {
      console.error("Error opening link:", error);
      toast({
        title: "Error",
        description: "Could not open link, please try again",
        variant: "destructive",
      });
    }
  };
  
  const handleClaimReward = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isClaiming || !visitId) return;
    
    setIsClaiming(true);
    
    try {
      const response = await fetch(`/api/claim-reward/${visitId}`, {
        method: 'POST'
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Actualizar el estado para ocultar el botón de reclamar
        setShowClaim(false);
        setVisitId(undefined);
        
        // Actualizar los datos del usuario (saldo de Zcoin)
        queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
        
        toast({
          title: "Reward claimed!",
          description: `You've earned ${data.rewardAmount} Zcoins!`,
        });
      } else {
        toast({
          title: "Could not claim reward",
          description: data.message || "Please try again later",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error claiming reward:", error);
      toast({
        title: "Error",
        description: "Could not claim reward, please try again",
        variant: "destructive",
      });
    } finally {
      setIsClaiming(false);
    }
  };

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const threshold = 100; // Umbral para considerar el deslizamiento
    
    if (info.offset.x < -threshold) {
      // Deslizado a la izquierda - eliminar
      controls.start({ x: -200, opacity: 0 }).then(() => {
        handleDelete(event as any);
      });
    } else if (info.offset.x > threshold) {
      // Deslizado a la derecha - abrir enlace
      controls.start({ x: 200, opacity: 0 }).then(() => {
        openLink();
        // Recuperar posición original
        setTimeout(() => {
          controls.start({ x: 0, opacity: 1 });
        }, 300);
      });
    } else {
      // No alcanzó el umbral, volver a la posición original
      controls.start({ x: 0 });
    }
  };

  return (
    <div className={cn("bg-dark-card rounded-xl mb-3 overflow-hidden relative", className)}>
      {/* Indicadores de acción que se muestran al deslizar */}
      <div className="absolute inset-0 flex justify-between items-center px-6 pointer-events-none">
        <div className="bg-red-500/20 h-full flex items-center justify-center rounded-l-xl pl-4">
          <Trash2 className="h-5 w-5 text-red-500" />
        </div>
        <div className="bg-blue-500/20 h-full flex items-center justify-center rounded-r-xl pr-4">
          <ExternalLink className="h-5 w-5 text-blue-500" />
        </div>
      </div>
      
      <motion.div 
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        onDragEnd={handleDragEnd}
        animate={controls}
        className="relative bg-dark-card z-10"
      >
        {/* Si el usuario puede reclamar su recompensa, mostrar una interfaz diferente */}
        {showClaim ? (
          <div className="p-4 flex flex-col items-center">
            <div className="mb-2 text-center">
              <h3 className="font-medium text-lg mb-1">App opened successfully!</h3>
              <p className="text-gray-400 text-sm">Claim your reward now</p>
            </div>
            
            <button
              onClick={handleClaimReward}
              disabled={isClaiming}
              className="px-6 py-3 bg-gradient-to-r from-zcoin-gold to-yellow-500 text-black font-semibold rounded-xl w-full flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
            >
              <Gift className="h-5 w-5" />
              {isClaiming ? "Claiming..." : "Claim 10 Zcoins"}
            </button>
          </div>
        ) : (
          <div className="flex items-center p-4">
            <div className="flex-shrink-0 mr-3">
              <AppLogo 
                withBackground 
                backgroundColor={link.iconType} 
                size="md"
                type={getAppType()}
              />
            </div>
            <div className="flex-grow">
              <div className="flex items-center">
                <h3 className="font-medium">{link.name}</h3>
                {link.isOverlinked && (
                  <div className="ml-2 px-2 py-0.5 bg-yellow-500/20 text-yellow-500 text-xs rounded-full flex items-center">
                    <AlertCircle className="mr-1 h-3 w-3" />
                    Overlinked
                  </div>
                )}
                {link.hasCoin && (
                  <div className="ml-2 flex items-center text-zcoin-gold">
                    <Coins className="h-3 w-3 mr-1" />
                  </div>
                )}
              </div>
              <div className="text-gray-400 text-sm flex items-center">
                {link.clicks} Clicks 
                {link.recentClicks && (
                  <span className="ml-1 text-green-500 text-xs">(+{link.recentClicks})</span>
                )}
              </div>
            </div>
            <div className="flex-shrink-0 text-right">
              <div className="flex items-center justify-end mb-1">
                <ArrowUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-green-500 font-semibold">{link.rank}th</span>
              </div>
              <div className="text-gray-400 text-xs">/ {link.totalLinks} links</div>
            </div>
            
            {/* Botón de eliminar */}
            <button 
              onClick={handleDelete}
              disabled={isDeleting}
              className="ml-2 p-2 text-red-500 hover:bg-red-500/10 rounded-full transition-colors"
              aria-label="Delete link"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
