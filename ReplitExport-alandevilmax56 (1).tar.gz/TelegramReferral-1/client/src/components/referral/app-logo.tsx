import { cn } from "@/lib/utils";
import { Bot, Flame, Rocket, Shield, Zap, MessageSquareText, Music, Video, Image } from "lucide-react";

export type AppIconType = "bot" | "game" | "tool" | "security" | "chat" | "music" | "video" | "image" | "default";

interface AppLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  type?: AppIconType;
  withBackground?: boolean;
  backgroundColor?: "blue" | "purple" | "gold" | "red";
}

export function AppLogo({ 
  className, 
  size = "md", 
  type = "default",
  withBackground = false,
  backgroundColor = "blue"
}: AppLogoProps) {
  const sizeClasses = {
    sm: "h-5 w-5",
    md: "h-6 w-6",
    lg: "h-8 w-8"
  };
  
  const backgroundColorClasses = {
    blue: "from-zcoin-blue/80 to-zcoin-blue/20 border-blue-400/40",
    purple: "from-zcoin-purple/80 to-zcoin-purple/20 border-purple-400/40",
    gold: "from-zcoin-gold/80 to-zcoin-gold/20 border-yellow-400/40",
    red: "from-red-500/80 to-red-500/20 border-red-400/40",
  };

  // Map de tipos de aplicación a sus iconos correspondientes
  const iconMap = {
    bot: <Bot className={cn("text-white", sizeClasses[size])} />,
    game: <Flame className={cn("text-white", sizeClasses[size])} />,
    tool: <Rocket className={cn("text-white", sizeClasses[size])} />,
    security: <Shield className={cn("text-white", sizeClasses[size])} />,
    chat: <MessageSquareText className={cn("text-white", sizeClasses[size])} />,
    music: <Music className={cn("text-white", sizeClasses[size])} />,
    video: <Video className={cn("text-white", sizeClasses[size])} />,
    image: <Image className={cn("text-white", sizeClasses[size])} />,
    default: <Zap className={cn("text-white", sizeClasses[size])} />
  };

  return (
    <div className={cn(
      withBackground && "rounded-full bg-gradient-to-br flex items-center justify-center border",
      withBackground && backgroundColorClasses[backgroundColor],
      withBackground && {
        "h-8 w-8": size === "sm",
        "h-12 w-12": size === "md",
        "h-16 w-16": size === "lg"
      },
      className
    )}>
      {iconMap[type]}
    </div>
  );
}