import { useLocation } from "wouter";
import { Zap, ListChecks, Users } from "lucide-react";

export function NavigationTabs() {
  const [, navigate] = useLocation();

  const handleQuests = () => navigate("/quests");
  const handleBoost = () => navigate("/referral-listing");
  const handleFriends = () => navigate("/referral-link");

  return (
    <div className="grid grid-cols-3 gap-4 mt-4 px-4">
      <div 
        className="bg-gradient-to-br from-zcoin-blue to-zcoin-blue/70 rounded-xl p-3 shadow-lg text-center cursor-pointer"
        onClick={handleQuests}
      >
        <div className="bg-white/20 h-8 w-8 mx-auto rounded-lg flex items-center justify-center mb-2">
          <ListChecks className="h-5 w-5" />
        </div>
        <span className="text-sm font-medium">Quests</span>
      </div>
      
      <div 
        className="bg-gradient-to-br from-zcoin-blue to-zcoin-blue/70 rounded-xl p-3 shadow-lg text-center cursor-pointer"
        onClick={handleBoost}
      >
        <div className="bg-white/20 h-8 w-8 mx-auto rounded-lg flex items-center justify-center mb-2">
          <Zap className="h-5 w-5" />
        </div>
        <span className="text-sm font-medium">Boost your links</span>
      </div>
      
      <div 
        className="bg-gradient-to-br from-zcoin-blue to-zcoin-blue/70 rounded-xl p-3 shadow-lg text-center cursor-pointer"
        onClick={handleFriends}
      >
        <div className="bg-white/20 h-8 w-8 mx-auto rounded-lg flex items-center justify-center mb-2">
          <Users className="h-5 w-5" />
        </div>
        <span className="text-sm font-medium">Friends</span>
      </div>
    </div>
  );
}
