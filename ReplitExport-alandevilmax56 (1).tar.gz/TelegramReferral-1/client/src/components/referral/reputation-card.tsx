import { Card } from "@/components/ui/card";
import { ZcoinLogo } from "@/components/ui/zcoin-logo";

interface ReputationCardProps {
  rank: number;
  todayRep: number;
}

export function ReputationCard({ rank, todayRep }: ReputationCardProps) {
  return (
    <Card className="bg-dark-card mx-4 mt-4 rounded-xl p-4 shadow-lg border-none">
      <h2 className="text-center text-xl mb-2">Your Referral Zcoin</h2>

      <div className="flex items-center justify-center my-3">
        <div className="relative">
          <span className="text-gray-400 text-4xl font-mono absolute -left-4 top-4">#</span>
          <div className="flex items-center">
            <span className="text-6xl font-bold text-white/90 font-mono">{rank}</span>
            <div className="relative ml-2">
              <ZcoinLogo withBackground backgroundColor="purple" size="md" />
              <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-dark-card"></span>
            </div>
          </div>
        </div>
      </div>

      <p className="text-center text-gray-300 mb-1">Raise your reputation to get more clicks.</p>
      <div className="text-center text-zcoin-gold font-medium mb-4">Today: <span>+{todayRep} Zcoin</span></div>
    </Card>
  );
}