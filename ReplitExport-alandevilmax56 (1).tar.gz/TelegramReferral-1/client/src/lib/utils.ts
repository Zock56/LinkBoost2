import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Animate reputation gain
export function animateRepGain(amount: number) {
  const repElement = document.createElement("div");
  repElement.classList.add("fixed", "z-50", "text-zcoin-blue", "font-bold", "text-lg");
  repElement.style.top = "50%";
  repElement.style.left = "50%";
  repElement.style.transform = "translate(-50%, -50%)";
  repElement.style.animation = "fadeUpAndOut 1.5s ease-out forwards";
  repElement.textContent = `+${amount} REP`;
  document.body.appendChild(repElement);

  setTimeout(() => {
    document.body.removeChild(repElement);
  }, 1500);
}

// Format numbers with commas
export function formatNumber(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Generate a random ID for elements
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}
