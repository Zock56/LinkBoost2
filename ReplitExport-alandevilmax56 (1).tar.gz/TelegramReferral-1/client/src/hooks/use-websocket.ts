import { useState, useEffect, useRef, useCallback } from 'react';

interface WebSocketOptions {
  onOpen?: (event: Event) => void;
  onMessage?: (event: MessageEvent) => void;
  onClose?: (event: CloseEvent) => void;
  onError?: (event: Event) => void;
  reconnectInterval?: number;
  reconnectAttempts?: number;
}

export function useWebSocket(
  path: string = '/ws',
  options: WebSocketOptions = {}
) {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<MessageEvent | null>(null);
  const [reconnectCount, setReconnectCount] = useState(0);
  
  const websocketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);
  
  const {
    onOpen,
    onMessage,
    onClose,
    onError,
    reconnectInterval = 3000,
    reconnectAttempts = 5,
  } = options;
  
  // Función para establecer la conexión WebSocket
  const connect = useCallback(() => {
    if (websocketRef.current?.readyState === WebSocket.OPEN) {
      return;
    }
    
    try {
      // Construir la URL del WebSocket usando el protocolo correcto
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}${path}`;
      
      const ws = new WebSocket(wsUrl);
      
      ws.onopen = (event) => {
        console.log('WebSocket connection established');
        setIsConnected(true);
        setReconnectCount(0);
        onOpen?.(event);
      };
      
      ws.onmessage = (event) => {
        setLastMessage(event);
        onMessage?.(event);
      };
      
      ws.onclose = (event) => {
        console.log('WebSocket connection closed');
        setIsConnected(false);
        onClose?.(event);
        
        // Intentar reconectar si no fue un cierre limpio y no hemos excedido los intentos
        if (
          !event.wasClean && 
          reconnectCount < reconnectAttempts
        ) {
          const timeout = window.setTimeout(() => {
            setReconnectCount((count) => count + 1);
            connect();
          }, reconnectInterval);
          
          reconnectTimeoutRef.current = timeout;
        }
      };
      
      ws.onerror = (event) => {
        console.error('WebSocket error:', event);
        onError?.(event);
      };
      
      websocketRef.current = ws;
    } catch (error) {
      console.error('Error creating WebSocket connection:', error);
    }
  }, [
    path,
    onOpen,
    onMessage,
    onClose,
    onError,
    reconnectInterval,
    reconnectAttempts,
    reconnectCount,
  ]);
  
  // Función para enviar mensajes
  const sendMessage = useCallback((data: any) => {
    if (
      websocketRef.current && 
      websocketRef.current.readyState === WebSocket.OPEN
    ) {
      websocketRef.current.send(JSON.stringify(data));
      return true;
    }
    return false;
  }, []);
  
  // Función para cerrar la conexión
  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      window.clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    if (websocketRef.current) {
      websocketRef.current.close();
      websocketRef.current = null;
    }
  }, []);
  
  // Establecer la conexión al montar el componente
  useEffect(() => {
    connect();
    
    // Limpiar al desmontar
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);
  
  return {
    isConnected,
    lastMessage,
    sendMessage,
    websocket: websocketRef.current,
    connect,
    disconnect,
  };
}