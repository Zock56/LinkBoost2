import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Crear aplicación Express
const app = express();
const PORT = 3000;

// Servir archivos estáticos desde el directorio public
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Datos de rendimiento de muestra
const performanceData = {
  totalClicks: 45,
  totalUniqueVisitors: 25,
  totalCompletedVisits: 15,
  totalRewardsEarned: 150,
  averageConversionRate: 33.3,
  topPerformingLinks: [
    {
      linkId: 1,
      name: "DreamStation A",
      clicks: 20,
      conversionRate: 40
    },
    {
      linkId: 2,
      name: "Virtual Tether",
      clicks: 15,
      conversionRate: 33.3
    },
    {
      linkId: 3,
      name: "tBTC Hash",
      clicks: 10,
      conversionRate: 20
    }
  ],
  performanceByDate: [
    {
      date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
      clicks: 5,
      uniqueVisitors: 3,
      completedVisits: 1
    },
    {
      date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      clicks: 8,
      uniqueVisitors: 6,
      completedVisits: 2
    },
    {
      date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      clicks: 7,
      uniqueVisitors: 4,
      completedVisits: 3
    },
    {
      date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      clicks: 10,
      uniqueVisitors: 6,
      completedVisits: 4
    },
    {
      date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      clicks: 8,
      uniqueVisitors: 5,
      completedVisits: 3
    },
    {
      date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      clicks: 7,
      uniqueVisitors: 4,
      completedVisits: 2
    }
  ]
};

// API para obtener datos de rendimiento
app.get('/api/performance/summary', (req, res) => {
  res.json(performanceData);
});

// Endpoint para verificar salud del servidor 
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Página principal
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// Iniciar servidor
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// Manejo de señales para cierre gracioso
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});