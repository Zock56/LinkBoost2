#!/bin/bash

# Matar cualquier proceso que pueda estar corriendo en el puerto 5173
pkill -f "node simple-server.js" || true

# Iniciar servidor simple
node simple-server.js &

echo "Servidor API de rendimiento iniciado en segundo plano"
