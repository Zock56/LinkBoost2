#!/bin/bash

# Matar cualquier proceso que pueda estar corriendo en los puertos 3000 o 5000
pkill -f node || true

# Iniciar aplicación con Node.js (usando la opción --experimental-modules para ESM)
node --experimental-modules app.js