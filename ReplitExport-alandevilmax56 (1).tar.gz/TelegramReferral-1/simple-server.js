const express = require('express');
const app = express();
const PORT = 5173;

// Datos de ejemplo
const performanceData = {
  totalClicks: 45,
  totalUniqueVisitors: 25,
  totalCompletedVisits: 15,
  totalRewardsEarned: 150,
  averageConversionRate: 33.3,
  topPerformingLinks: [
    { linkId: 1, name: "DreamStation A", clicks: 20, conversionRate: 40 },
    { linkId: 2, name: "Virtual Tether", clicks: 15, conversionRate: 33.3 },
    { linkId: 3, name: "tBTC Hash", clicks: 10, conversionRate: 20 }
  ],
  performanceByDate: [
    { date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000), clicks: 5, uniqueVisitors: 3, completedVisits: 1 },
    { date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), clicks: 8, uniqueVisitors: 6, completedVisits: 2 },
    { date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000), clicks: 7, uniqueVisitors: 4, completedVisits: 3 },
    { date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), clicks: 10, uniqueVisitors: 6, completedVisits: 4 },
    { date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), clicks: 8, uniqueVisitors: 5, completedVisits: 3 },
    { date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), clicks: 7, uniqueVisitors: 4, completedVisits: 2 }
  ]
};

// API para obtener datos del rendimiento
app.get('/api/performance/summary', (req, res) => {
  res.json(performanceData);
});

// Página de estado
app.get('/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

// Iniciar el servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor de API de rendimiento ejecutándose en http://localhost:${PORT}`);
});
