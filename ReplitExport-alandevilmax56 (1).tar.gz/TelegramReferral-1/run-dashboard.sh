#!/bin/bash

# Matar cualquier proceso que pueda estar corriendo en los puertos 3000 o 5000
pkill -f node || true

# Iniciar aplicación con Node.js (formato CommonJS estándar)
node dashboard.cjs