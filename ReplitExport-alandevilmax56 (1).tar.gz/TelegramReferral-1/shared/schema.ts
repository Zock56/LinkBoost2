import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  telegramId: text("telegram_id").notNull().unique(),
  reputation: integer("reputation").notNull().default(0),
  rank: integer("rank").notNull().default(0),
  todayRep: integer("today_rep").notNull().default(0),
  friendsInvited: integer("friends_invited").notNull().default(0),
  totalRepFromFriends: integer("total_rep_from_friends").notNull().default(0),
  zcoinBalance: integer("zcoin_balance").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  telegramId: true,
});

// Referral links table
export const referralLinks = pgTable("referral_links", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  clicks: integer("clicks").notNull().default(0),
  recentClicks: integer("recent_clicks"),
  rank: integer("rank").notNull().default(0),
  totalLinks: integer("total_links").notNull().default(0),
  isOverlinked: boolean("is_overlinked").notNull().default(false),
  hasCoin: boolean("has_coin").notNull().default(false),
  iconType: text("icon_type").notNull().default("blue"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertReferralLinkSchema = createInsertSchema(referralLinks).pick({
  userId: true,
  name: true,
  iconType: true,
});

// Quests table
export const quests = pgTable("quests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  repReward: integer("rep_reward").notNull(),
  zcoinReward: integer("zcoin_reward"),
  isDaily: boolean("is_daily").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertQuestSchema = createInsertSchema(quests).pick({
  name: true,
  description: true,
  repReward: true,
  zcoinReward: true,
  isDaily: true,
});

// User quests progress
export const userQuestProgress = pgTable("user_quest_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  questId: integer("quest_id").notNull().references(() => quests.id),
  currentLevel: integer("current_level").notNull().default(0),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserQuestProgressSchema = createInsertSchema(userQuestProgress).pick({
  userId: true,
  questId: true,
});

// Available links
export const availableLinks = pgTable("available_links", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  iconType: text("icon_type").notNull().default("blue"),
  rank: integer("rank"),
  totalLinks: integer("total_links"),
  forUser: text("for_user"),
  repAmount: integer("rep_amount"),
  fromUser: text("from_user"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertAvailableLinkSchema = createInsertSchema(availableLinks).pick({
  name: true,
  iconType: true,
  rank: true,
  totalLinks: true,
  forUser: true,
  repAmount: true,
  fromUser: true,
});

// Define types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ReferralLink = typeof referralLinks.$inferSelect;
export type InsertReferralLink = z.infer<typeof insertReferralLinkSchema>;

export type Quest = typeof quests.$inferSelect;
export type InsertQuest = z.infer<typeof insertQuestSchema>;

export type UserQuestProgress = typeof userQuestProgress.$inferSelect;
export type InsertUserQuestProgress = z.infer<typeof insertUserQuestProgressSchema>;

export type AvailableLink = typeof availableLinks.$inferSelect;
export type InsertAvailableLink = z.infer<typeof insertAvailableLinkSchema>;

// Sistema Anti-Fraude
export const clickLogs = pgTable("click_logs", {
  id: serial("id").primaryKey(),
  linkId: integer("link_id").notNull().references(() => referralLinks.id),
  userId: integer("user_id"),
  ipAddress: text("ip_address").notNull(),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  fraudScore: integer("fraud_score").notNull().default(0),
  isValid: boolean("is_valid").notNull().default(true),
  metadata: jsonb("metadata"),
});

export const insertClickLogSchema = createInsertSchema(clickLogs).pick({
  linkId: true,
  userId: true,
  ipAddress: true,
  userAgent: true,
  fraudScore: true,
  isValid: true,
  metadata: true,
});

export const fraudRules = pgTable("fraud_rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  condition: jsonb("condition").notNull(),
  scoreImpact: integer("score_impact").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFraudRuleSchema = createInsertSchema(fraudRules).pick({
  name: true,
  description: true,
  condition: true,
  scoreImpact: true,
  isActive: true,
});

export const ipRestrictions = pgTable("ip_restrictions", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address").notNull().unique(),
  restrictionType: text("restriction_type").notNull(),
  reason: text("reason"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertIpRestrictionSchema = createInsertSchema(ipRestrictions).pick({
  ipAddress: true,
  restrictionType: true,
  reason: true,
  expiresAt: true,
});

export type ClickLog = typeof clickLogs.$inferSelect;
export type InsertClickLog = z.infer<typeof insertClickLogSchema>;

export type FraudRule = typeof fraudRules.$inferSelect;
export type InsertFraudRule = z.infer<typeof insertFraudRuleSchema>;

export type IpRestriction = typeof ipRestrictions.$inferSelect;
export type InsertIpRestriction = z.infer<typeof insertIpRestrictionSchema>;

// Sistema de reclamación de recompensas
export const linkVisits = pgTable("link_visits", {
  id: serial("id").primaryKey(),
  linkId: integer("link_id").notNull().references(() => referralLinks.id),
  userId: integer("user_id").references(() => users.id),
  ipAddress: text("ip_address").notNull(),
  visited: boolean("visited").notNull().default(false),
  claimed: boolean("claimed").notNull().default(false),
  visitedAt: timestamp("visited_at"),
  claimedAt: timestamp("claimed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLinkVisitSchema = createInsertSchema(linkVisits).pick({
  linkId: true,
  userId: true,
  ipAddress: true,
  visited: true,
  claimed: true,
  visitedAt: true,
  claimedAt: true,
});

export type LinkVisit = typeof linkVisits.$inferSelect;
export type InsertLinkVisit = z.infer<typeof insertLinkVisitSchema>;

// Estadísticas de rendimiento de enlaces referidos
export const linkPerformance = pgTable("link_performance", {
  id: serial("id").primaryKey(),
  linkId: integer("link_id").notNull().references(() => referralLinks.id),
  date: timestamp("date").notNull(),
  clicks: integer("clicks").notNull().default(0),
  uniqueVisitors: integer("unique_visitors").notNull().default(0),
  completedVisits: integer("completed_visits").notNull().default(0),
  rewardsEarned: integer("rewards_earned").notNull().default(0),
  conversionRate: text("conversion_rate").notNull().default("0"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLinkPerformanceSchema = createInsertSchema(linkPerformance).pick({
  linkId: true,
  date: true,
  clicks: true,
  uniqueVisitors: true,
  completedVisits: true,
  rewardsEarned: true,
  conversionRate: true,
});

export type LinkPerformance = typeof linkPerformance.$inferSelect;
export type InsertLinkPerformance = z.infer<typeof insertLinkPerformanceSchema>;
