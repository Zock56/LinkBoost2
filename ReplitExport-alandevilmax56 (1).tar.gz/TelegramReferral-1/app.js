// Servidor Express super simple para mostrar panel de rendimiento
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Crear la aplicación Express
const app = express();
const PORT = 3000;

// Datos de rendimiento (simulados)
const performanceData = {
  totalClicks: 45,
  totalUniqueVisitors: 25,
  totalCompletedVisits: 15,
  totalRewardsEarned: 150,
  averageConversionRate: 33.3,
  topPerformingLinks: [
    { linkId: 1, name: "DreamStation A", clicks: 20, conversionRate: 40 },
    { linkId: 2, name: "Virtual Tether", clicks: 15, conversionRate: 33.3 },
    { linkId: 3, name: "tBTC Hash", clicks: 10, conversionRate: 20 }
  ],
  performanceByDate: [
    { date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000), clicks: 5, uniqueVisitors: 3, completedVisits: 1 },
    { date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), clicks: 8, uniqueVisitors: 6, completedVisits: 2 },
    { date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000), clicks: 7, uniqueVisitors: 4, completedVisits: 3 },
    { date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), clicks: 10, uniqueVisitors: 6, completedVisits: 4 },
    { date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), clicks: 8, uniqueVisitors: 5, completedVisits: 3 },
    { date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), clicks: 7, uniqueVisitors: 4, completedVisits: 2 }
  ]
};

// HTML para la página de inicio
const homePageHTML = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LinkBoost - Panel de Rendimiento</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #0f172a;
      color: #f1f5f9;
      font-family: 'Inter', sans-serif;
    }
    .circuit-bg {
      background-image: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%232563eb' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E");
    }
    .zcoin-gradient {
      background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    }
  </style>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="circuit-bg min-h-screen">
  <div class="container mx-auto px-4 py-8">
    <!-- Encabezado -->
    <header class="flex justify-between items-center mb-8">
      <div class="flex items-center space-x-3">
        <div class="w-10 h-10 rounded-full zcoin-gradient flex items-center justify-center shadow-lg">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </div>
        <h1 class="text-2xl font-bold">LinkBoost</h1>
      </div>
      <div class="flex items-center space-x-2">
        <div class="bg-blue-900 bg-opacity-40 p-2 rounded-lg text-sm">
          <span class="text-blue-300">Zcoins:</span> <span id="userZcoins">250</span>
        </div>
        <div class="bg-blue-900 bg-opacity-40 p-2 rounded-lg text-sm">
          <span class="text-blue-300">Rep:</span> <span id="userRep">100</span>
        </div>
      </div>
    </header>

    <!-- Panel de Rendimiento -->
    <div class="zcoin-gradient p-1 rounded-xl shadow-xl mb-6">
      <div class="bg-slate-900 rounded-lg p-4">
        <h2 class="text-xl font-semibold mb-4">Panel de Rendimiento</h2>
        
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div class="bg-slate-800 p-4 rounded-lg">
            <p class="text-blue-300 text-sm">Clics Totales</p>
            <p class="text-2xl font-bold" id="totalClicks">--</p>
          </div>
          <div class="bg-slate-800 p-4 rounded-lg">
            <p class="text-blue-300 text-sm">Visitantes Únicos</p>
            <p class="text-2xl font-bold" id="uniqueVisitors">--</p>
          </div>
          <div class="bg-slate-800 p-4 rounded-lg">
            <p class="text-blue-300 text-sm">Visitas Completadas</p>
            <p class="text-2xl font-bold" id="completedVisits">--</p>
          </div>
          <div class="bg-slate-800 p-4 rounded-lg">
            <p class="text-blue-300 text-sm">Recompensas Ganadas</p>
            <p class="text-2xl font-bold" id="rewardsEarned">--</p>
          </div>
        </div>
        
        <!-- Gráfico de Rendimiento -->
        <div class="bg-slate-800 p-4 rounded-lg mb-6">
          <h3 class="text-lg font-medium mb-4">Rendimiento en el Tiempo</h3>
          <div class="h-60 w-full">
            <canvas id="lineChart"></canvas>
          </div>
        </div>
        
        <!-- Enlaces de Mejor Rendimiento -->
        <div class="bg-slate-800 p-4 rounded-lg">
          <h3 class="text-lg font-medium mb-4">Enlaces de Mejor Rendimiento</h3>
          <div class="overflow-x-auto">
            <table class="w-full">
              <thead>
                <tr class="text-blue-300 text-left">
                  <th class="pb-2">Nombre</th>
                  <th class="pb-2">Clics</th>
                  <th class="pb-2">Tasa de Conversión</th>
                </tr>
              </thead>
              <tbody id="topLinksTable">
                <tr>
                  <td colspan="3" class="text-center py-4">Cargando datos...</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Navegación Inferior -->
    <div class="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-blue-900 py-2">
      <div class="container mx-auto px-4">
        <div class="flex justify-around">
          <a href="#" class="flex flex-col items-center text-blue-400">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            <span class="text-xs">Inicio</span>
          </a>
          <a href="#" class="flex flex-col items-center text-gray-500">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span class="text-xs">Misiones</span>
          </a>
          <a href="#" class="flex flex-col items-center text-gray-500">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
            <span class="text-xs">Enlaces</span>
          </a>
          <a href="#" class="flex flex-col items-center text-blue-500">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <span class="text-xs">Rendimiento</span>
          </a>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Función para cargar los datos
    async function loadDashboardData() {
      try {
        const response = await fetch('/api/performance/summary');
        const data = await response.json();
        
        // Actualizar contadores
        document.getElementById('totalClicks').textContent = data.totalClicks;
        document.getElementById('uniqueVisitors').textContent = data.totalUniqueVisitors;
        document.getElementById('completedVisits').textContent = data.totalCompletedVisits;
        document.getElementById('rewardsEarned').textContent = data.totalRewardsEarned;
        
        // Actualizar tabla de mejores enlaces
        const tableBody = document.getElementById('topLinksTable');
        tableBody.innerHTML = '';
        
        data.topPerformingLinks.forEach(link => {
          const row = document.createElement('tr');
          row.innerHTML = \`
            <td class="py-2">\${link.name}</td>
            <td class="py-2">\${link.clicks}</td>
            <td class="py-2">\${link.conversionRate}%</td>
          \`;
          tableBody.appendChild(row);
        });
        
        // Preparar datos para el gráfico
        const ctx = document.getElementById('lineChart').getContext('2d');
        
        const labels = data.performanceByDate.map(item => {
          const date = new Date(item.date);
          return date.toLocaleDateString();
        });
        
        const clicksData = data.performanceByDate.map(item => item.clicks);
        const visitorsData = data.performanceByDate.map(item => item.uniqueVisitors);
        const completedData = data.performanceByDate.map(item => item.completedVisits);
        
        new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            datasets: [
              {
                label: 'Clics',
                data: clicksData,
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                tension: 0.4,
                fill: true
              },
              {
                label: 'Visitantes',
                data: visitorsData,
                borderColor: '#8b5cf6',
                backgroundColor: 'rgba(139, 92, 246, 0.1)',
                tension: 0.4,
                fill: true
              },
              {
                label: 'Completados',
                data: completedData,
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
                fill: true
              }
            ]
          },
          options: {
            responsive: true,
            plugins: {
              legend: {
                position: 'top',
                labels: {
                  color: '#f1f5f9'
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(71, 85, 105, 0.3)'
                },
                ticks: {
                  color: '#94a3b8'
                }
              },
              x: {
                grid: {
                  color: 'rgba(71, 85, 105, 0.3)'
                },
                ticks: {
                  color: '#94a3b8'
                }
              }
            }
          }
        });
      } catch (error) {
        console.error('Error al cargar los datos:', error);
      }
    }
    
    // Cargar datos cuando la página se carga
    document.addEventListener('DOMContentLoaded', loadDashboardData);
  </script>
</body>
</html>`;

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Endpoint API para datos de rendimiento
app.get('/api/performance/summary', (req, res) => {
  res.json(performanceData);
});

// Página principal
app.get('/', (req, res) => {
  res.send(homePageHTML);
});

// Endpoint de estado
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', uptime: process.uptime() });
});

// Iniciar el servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`¡Servidor ejecutándose en http://localhost:${PORT}!`);
});